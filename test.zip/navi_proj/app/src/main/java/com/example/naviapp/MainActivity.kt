package com.example.naviapp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONArray
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                NaviApp()
            }
        }
    }
}

data class NavRoute(
    val points: List<GeoPoint>,
    val distanceKm: Double,
    val durationMin: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NaviApp() {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()

    var locationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var currentLocation by remember { mutableStateOf<GeoPoint?>(null) }
    var destination by remember { mutableStateOf<GeoPoint?>(null) }
    var destinationName by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var route by remember { mutableStateOf<NavRoute?>(null) }
    var isNavigating by remember { mutableStateOf(false) }
    var isSearching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf("") }

    var mapView by remember { mutableStateOf<MapView?>(null) }
    var locationOverlay by remember { mutableStateOf<MyLocationNewOverlay?>(null) }
    var destMarker by remember { mutableStateOf<Marker?>(null) }
    var routeLine by remember { mutableStateOf<Polyline?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        locationPermission = granted
        if (granted) {
            locationOverlay?.enableMyLocation()
            locationOverlay?.enableFollowLocation()
        }
    }

    val locationManager = remember {
        context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    DisposableEffect(locationPermission) {
        var locationListener: LocationListener? = null
        if (locationPermission) {
            locationListener = LocationListener { location ->
                val gp = GeoPoint(location.latitude, location.longitude)
                currentLocation = gp
                val dest = destination
                if (dest != null) {
                    val dist = gp.distanceToAsDouble(dest) / 1000.0
                    val dur = (dist / 40.0 * 60).toInt()
                    route = route?.copy(distanceKm = dist, durationMin = dur)
                }
            }
            try {
                if (ContextCompat.checkSelfPermission(
                        context, Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                        .filter { locationManager.isProviderEnabled(it) }
                        .forEach { provider ->
                            locationManager.requestLocationUpdates(
                                provider, 1000L, 5f, locationListener
                            )
                        }
                    val lastLoc = listOf(
                        locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER),
                        locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    ).filterNotNull().minByOrNull { it.accuracy }
                    lastLoc?.let { currentLocation = GeoPoint(it.latitude, it.longitude) }
                }
            } catch (_: Exception) {}
        }
        onDispose {
            locationListener?.let { locationManager.removeUpdates(it) }
        }
    }

    fun updateMapWithDestination(mv: MapView, destPoint: GeoPoint, name: String) {
        destMarker?.let { mv.overlays.remove(it) }
        val marker = Marker(mv).apply {
            position = destPoint
            title = name
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        }
        mv.overlays.add(marker)
        destMarker = marker

        routeLine?.let { mv.overlays.remove(it) }
        val from = currentLocation ?: GeoPoint(destPoint.latitude + 0.01, destPoint.longitude + 0.01)
        val pts = listOf(from, destPoint)
        val polyline = Polyline(mv).apply {
            setPoints(pts)
            outlinePaint.color = android.graphics.Color.parseColor("#2979FF")
            outlinePaint.strokeWidth = 14f
        }
        mv.overlays.add(0, polyline)
        routeLine = polyline

        val distKm = from.distanceToAsDouble(destPoint) / 1000.0
        val durationMin = (distKm / 40.0 * 60).toInt()
        route = NavRoute(pts, distKm, durationMin)
        mv.invalidate()
    }

    fun searchDestination(query: String) {
        if (query.isBlank()) return
        isSearching = true
        searchError = ""
        scope.launch(Dispatchers.IO) {
            try {
                val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
                val url =
                    URL("https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&limit=1")
                val conn = url.openConnection() as HttpURLConnection
                conn.setRequestProperty("User-Agent", "NaviApp/1.0 Android")
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val response = conn.inputStream.bufferedReader().readText()
                conn.disconnect()

                val array = JSONArray(response)
                if (array.length() > 0) {
                    val obj = array.getJSONObject(0)
                    val lat = obj.getDouble("lat")
                    val lon = obj.getDouble("lon")
                    val displayName = obj.getString("display_name").split(",")
                        .take(2).joinToString(", ")
                    val destPoint = GeoPoint(lat, lon)
                    withContext(Dispatchers.Main) {
                        destination = destPoint
                        destinationName = displayName
                        val mv = mapView ?: return@withContext
                        updateMapWithDestination(mv, destPoint, displayName)
                        mv.controller.animateTo(destPoint, 14.0, 1000L)
                        isNavigating = true
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        searchError = "場所が見つかりませんでした"
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    searchError = "検索エラー: ${e.message}"
                }
            } finally {
                withContext(Dispatchers.Main) {
                    isSearching = false
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapView(ctx).also { mv ->
                    mv.setTileSource(TileSourceFactory.MAPNIK)
                    mv.setMultiTouchControls(true)
                    mv.controller.setZoom(15.0)
                    mv.controller.setCenter(GeoPoint(35.6812, 139.7671))

                    val myLocOverlay = MyLocationNewOverlay(GpsMyLocationProvider(ctx), mv)
                    if (locationPermission) {
                        myLocOverlay.enableMyLocation()
                        myLocOverlay.enableFollowLocation()
                    }
                    mv.overlays.add(myLocOverlay)
                    locationOverlay = myLocOverlay

                    val mapEventsOverlay = MapEventsOverlay(object : MapEventsReceiver {
                        override fun singleTapConfirmedHelper(p: GeoPoint): Boolean = false
                        override fun longPressHelper(p: GeoPoint): Boolean {
                            val name = "%.4f, %.4f".format(p.latitude, p.longitude)
                            destination = p
                            destinationName = name
                            searchQuery = name
                            updateMapWithDestination(mv, p, "目的地")
                            isNavigating = true
                            return true
                        }
                    })
                    mv.overlays.add(mapEventsOverlay)
                    mapView = mv
                }
            },
            update = { mv ->
                currentLocation?.let { loc ->
                    if (locationOverlay?.myLocation == null) {
                        mv.controller.animateTo(loc, 15.0, 500L)
                    }
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 12.dp, end = 12.dp)
                .align(Alignment.TopCenter)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("目的地を検索（長押しでも設定可）") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {
                            focusManager.clearFocus()
                            searchDestination(searchQuery)
                        })
                    )
                    if (isSearching) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        IconButton(onClick = {
                            focusManager.clearFocus()
                            searchDestination(searchQuery)
                        }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "検索")
                        }
                    }
                }
            }

            if (searchError.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        text = searchError,
                        modifier = Modifier.padding(8.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        }

        FloatingActionButton(
            onClick = {
                if (!locationPermission) {
                    permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                } else {
                    currentLocation?.let { loc ->
                        mapView?.controller?.animateTo(loc, 15.0, 500L)
                    }
                    locationOverlay?.enableFollowLocation()
                }
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(
                    bottom = if (isNavigating) 200.dp else 16.dp,
                    end = 16.dp
                ),
            containerColor = MaterialTheme.colorScheme.primary
        ) {
            Icon(
                if (locationPermission) Icons.Default.MyLocation else Icons.Default.LocationOn,
                contentDescription = if (locationPermission) "現在地へ" else "位置情報を有効にする",
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }

        AnimatedVisibility(
            visible = isNavigating && route != null,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            route?.let { r ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    elevation = CardDefaults.cardElevation(8.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = destinationName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    maxLines = 1
                                )
                                Spacer(Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.DirectionsCar,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    val distStr = if (r.distanceKm < 1.0) {
                                        "%.0fm".format(r.distanceKm * 1000)
                                    } else {
                                        "%.1fkm".format(r.distanceKm)
                                    }
                                    Text(
                                        text = "$distStr  ·  約${r.durationMin}分",
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                            Row {
                                IconButton(onClick = {
                                    val dest = destination
                                    val cur = currentLocation
                                    if (dest != null && cur != null) {
                                        val midLat = (dest.latitude + cur.latitude) / 2
                                        val midLon = (dest.longitude + cur.longitude) / 2
                                        mapView?.controller?.animateTo(
                                            GeoPoint(midLat, midLon), 12.0, 500L
                                        )
                                    }
                                }) {
                                    Icon(
                                        Icons.Default.Map,
                                        contentDescription = "全体表示",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                IconButton(onClick = {
                                    isNavigating = false
                                    route = null
                                    destination = null
                                    destinationName = ""
                                    searchQuery = ""
                                    searchError = ""
                                    destMarker?.let { mapView?.overlays?.remove(it) }
                                    routeLine?.let { mapView?.overlays?.remove(it) }
                                    mapView?.invalidate()
                                }) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "閉じる",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }

                        val cur = currentLocation
                        val dest = destination
                        if (cur != null && dest != null) {
                            val bearing = bearingBetween(cur, dest)
                            val bearingText = bearingToText(bearing)
                            Spacer(Modifier.height(8.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f))
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Navigation,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "$bearingText 方向へ進んでください (${bearing.toInt()}°)",
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun bearingBetween(from: GeoPoint, to: GeoPoint): Double {
    val lat1 = Math.toRadians(from.latitude)
    val lat2 = Math.toRadians(to.latitude)
    val dLon = Math.toRadians(to.longitude - from.longitude)
    val y = sin(dLon) * cos(lat2)
    val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
    return (Math.toDegrees(atan2(y, x)) + 360) % 360
}

private fun bearingToText(bearing: Double): String = when {
    bearing < 22.5 || bearing >= 337.5 -> "北"
    bearing < 67.5 -> "北東"
    bearing < 112.5 -> "東"
    bearing < 157.5 -> "南東"
    bearing < 202.5 -> "南"
    bearing < 247.5 -> "南西"
    bearing < 292.5 -> "西"
    else -> "北西"
}
