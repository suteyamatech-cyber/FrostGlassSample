package com.example.neonavweatherytm

import android.app.Notification
import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class YtmNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        connectController()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == YTM_PKG) {
            parseNotification(sbn)
            connectController()
        }
    }

    private fun parseNotification(sbn: StatusBarNotification) {
        try {
            val n = sbn.notification ?: return
            val extras = n.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val art = extras.getParcelable<Bitmap>(Notification.EXTRA_LARGE_ICON)
                ?: extras.getParcelable<Bitmap>(Notification.EXTRA_LARGE_ICON_BIG)
            if (title.isNotBlank()) {
                YtmState.connected = true
                YtmState.title = title
                YtmState.artist = text
                if (art != null) YtmState.albumArt = art
            }
        } catch (t: Throwable) {
            Log.w("YtmNL", "parseNotification failed", t)
        }
    }

    private fun connectController() {
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, YtmNotificationListener::class.java)
            val controllers = msm.getActiveSessions(component)
            val ytm = controllers.firstOrNull { it.packageName == YTM_PKG }
            if (ytm == null) {
                YtmState.setDisconnected()
                return
            }
            YtmState.attach(ytm)
        } catch (t: Throwable) {
            Log.w("YtmNL", "connectController failed", t)
            YtmState.setDisconnected()
        }
    }

    companion object {
        private const val YTM_PKG = "com.google.android.apps.youtube.music"
    }
}

object YtmState {
    @Volatile var connected: Boolean = false
    @Volatile var title: String = "Not connected"
    @Volatile var artist: String = ""
    @Volatile var isPlaying: Boolean = false
    @Volatile var albumArt: Bitmap? = null

    @Volatile private var controller: MediaController? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            val t = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            val a = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
            if (t.isNotBlank()) title = t
            artist = a
            albumArt =
                metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                    ?: albumArt
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            isPlaying = state?.state == PlaybackState.STATE_PLAYING
        }
    }

    fun attach(c: MediaController) {
        try { controller?.unregisterCallback(callback) } catch (_: Throwable) {}
        controller = c
        connected = true

        val md = c.metadata
        val ps = c.playbackState
        title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: title
        artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: artist
        albumArt =
            md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                ?: albumArt
        isPlaying = ps?.state == PlaybackState.STATE_PLAYING

        c.registerCallback(callback)
    }

    fun setDisconnected() {
        try { controller?.unregisterCallback(callback) } catch (_: Throwable) {}
        controller = null
        connected = false
        title = "Not connected"
        artist = ""
        isPlaying = false
        albumArt = null
    }

    fun playPause() {
        val c = controller ?: return
        val tc = c.transportControls
        if (isPlaying) tc.pause() else tc.play()
    }
    fun next() { controller?.transportControls?.skipToNext() }
    fun prev() { controller?.transportControls?.skipToPrevious() }
}
