package com.example.neonavweatherytm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.util.GeoPoint
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Overpass API (OpenStreetMap) - no API key.
 * Fetch roads around current location and return a list of polylines (GeoPoint lists).
 */
suspend fun fetchRoadsOverpass(
    lat: Double,
    lon: Double,
    radiusMeters: Int = 1200,
): Result<List<List<GeoPoint>>> = withContext(Dispatchers.IO) {
    runCatching {
        val query =
            "[out:json][timeout:25];\n" +
            "(\n" +
            "  way(around:$radiusMeters,$lat,$lon)[\"highway\"];\n" +
            ");\n" +
            "out geom;\n"

        val url = URL("https://overpass-api.de/api/interpreter")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
        }

        BufferedWriter(OutputStreamWriter(conn.outputStream, Charsets.UTF_8)).use { w ->
            val body = "data=" + java.net.URLEncoder.encode(query, "UTF-8")
            w.write(body)
        }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream.bufferedReader().use { it.readText() }

        if (code !in 200..299) {
            throw IllegalStateException("Overpass HTTP $code: $body")
        }

        val json = JSONObject(body)
        val elems = json.optJSONArray("elements") ?: return@runCatching emptyList()

        val roads = ArrayList<List<GeoPoint>>(elems.length())
        for (i in 0 until elems.length()) {
            val e = elems.getJSONObject(i)
            if (e.optString("type") != "way") continue

            val tags = e.optJSONObject("tags")
            val hw = tags?.optString("highway") ?: ""

            // Visibility first: drop small paths
            if (hw in setOf("footway", "path", "cycleway", "steps", "pedestrian")) continue

            val geom = e.optJSONArray("geometry") ?: continue
            if (geom.length() < 2) continue

            val pts = ArrayList<GeoPoint>(geom.length())
            for (j in 0 until geom.length()) {
                val p = geom.getJSONObject(j)
                pts.add(GeoPoint(p.getDouble("lat"), p.getDouble("lon")))
            }
            roads.add(pts)
        }

        roads
    }
}
