package com.example.neonavweatherytm

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Help
import androidx.compose.material.icons.rounded.Thunderstorm
import androidx.compose.material.icons.rounded.Umbrella
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Grain
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.NearMe
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.JAPAN
                tts?.setSpeechRate(1.0f)
            }
        }

        setContent {
            MaterialTheme {
                AppRoot(speak = { speak(it) })
            }
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "neo-weather")
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

data class CurrentWeather(
    val temperatureC: Double,
    val windSpeed: Double,
    val weatherCode: Int
)

@Composable
private fun rememberHeadingDeg(): State<Float> {
    val ctx = LocalContext.current
    val heading = remember { mutableStateOf(0f) }
    val sm = remember { ctx.getSystemService(android.content.Context.SENSOR_SERVICE) as SensorManager }
    val sensor = remember { sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) }

    DisposableEffect(sensor) {
        if (sensor == null) {
            onDispose { }
        } else {
            val listener = object : SensorEventListener {
                private val rot = FloatArray(9)
                private val orient = FloatArray(3)
                override fun onSensorChanged(event: SensorEvent) {
                    try {
                        SensorManager.getRotationMatrixFromVector(rot, event.values)
                        SensorManager.getOrientation(rot, orient)
                        var deg = Math.toDegrees(orient[0].toDouble()).toFloat()
                        if (deg < 0f) deg += 360f
                        heading.value = deg
                    } catch (_: Throwable) { }
                }
                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
            }
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
            onDispose { sm.unregisterListener(listener) }
        }
    }
    return heading
}

@Composable
fun AppRoot(speak: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val fused = remember { LocationServices.getFusedLocationProviderClient(ctx) }

    var hasLocationPermission by remember { mutableStateOf(false) }
    var latLon by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var weather by remember { mutableStateOf<CurrentWeather?>(null) }
    var roads by remember { mutableStateOf<List<List<GeoPoint>>>(emptyList()) }
    var status by remember { mutableStateOf("Ready") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    // Nav-like controls
    val headingDeg = rememberHeadingDeg()
    var followMode by rememberSaveable { mutableStateOf(true) }
    var northUp by rememberSaveable { mutableStateOf(false) }

    val requestPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasLocationPermission = granted
        if (granted) {
            status = "Getting location..."
            getLocation(fused) { res ->
                res.onSuccess { ll ->
                    latLon = ll
                    status = "Location OK"
                }.onFailure { e ->
                    error = e.message
                    status = "Location failed"
                }
            }
        }
    }

    fun ensurePermissionAndFetch() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        hasLocationPermission = granted
        if (!granted) {
            requestPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            return
        }
        status = "Getting location..."
        getLocation(fused) { res ->
            res.onSuccess { ll ->
                latLon = ll
                status = "Location OK"
            }.onFailure { e ->
                error = e.message
                status = "Location failed"
            }
        }
    }

    // Auto on launch
    LaunchedEffect(Unit) {
        ensurePermissionAndFetch()
    }
    // Auto weather fetch when location updates
    LaunchedEffect(latLon) {
        val ll = latLon ?: return@LaunchedEffect
        loading = true
        status = "Fetching weather..."
        val r = fetchCurrentWeather(ll.first, ll.second)
        loading = false
        r.fold(
            onSuccess = {
                weather = it
                status = "Weather OK"
                speak(weatherSpeakText(it))
            },
            onFailure = { e ->
                error = e.message ?: "Weather failed"
                status = "Weather failed"
            }
        )
    }

// Auto roads fetch when location updates (Overpass API, no key)
LaunchedEffect(latLon) {
    val ll = latLon ?: return@LaunchedEffect
    status = "Fetching roads..."
    val r = fetchRoadsOverpass(ll.first, ll.second, radiusMeters = 1200)
    r.fold(
        onSuccess = { roads = it; status = "Roads OK" },
        onFailure = { e ->
            // do not fail the whole app; just show error
            error = e.message ?: "Roads failed"
            status = "Roads failed"
        }
    )
}

    Surface(Modifier.fillMaxSize(), color = Color(0xFF070A12)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(WindowInsets.systemBars.asPaddingValues())
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Neo Nav Weather", color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleLarge)
            Text(status, color = Color(0xFFA9B8FF))

            // Location + Map
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1426))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Location / Map", color = Color.White, fontWeight = FontWeight.Medium)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { ensurePermissionAndFetch() }) {
                            Icon(Icons.Rounded.NearMe, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("GPS")
                        }
                        AssistChip(onClick = { followMode = !followMode }, label = { Text(if (followMode) "Follow: ON" else "Follow: OFF") })
                        AssistChip(onClick = { northUp = !northUp }, label = { Text(if (northUp) "North Up: ON" else "North Up: OFF") })
                        Text("Heading: %d°".format(headingDeg.value.toInt()), color = Color(0xFFB8C7FF), style = MaterialTheme.typography.bodySmall)
                    }

                    val ll = latLon
                    if (ll != null) {
                        OsmMapWidget(
                            lat = ll.first,
                            lon = ll.second,
                            headingDeg = headingDeg.value,
                            followMode = followMode,
                            northUp = northUp,
                            roads = roads
                        )
                    } else {
                        Text("GPS未取得（権限許可後に自動で取得します）", color = Color(0xFFB8C7FF))
                    }
                }
            }

            // Weather
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1426))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Weather", color = Color.White, fontWeight = FontWeight.Medium)
                    val w = weather
                    if (w == null) {
                        Text(if (loading) "Loading..." else "No data", color = Color(0xFFE6ECFF))
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FuturisticWeatherIcon(code = w.weatherCode)
                            Column {
                                Text("${w.temperatureC.roundToInt()}°C", color = Color(0xFFE6ECFF), fontWeight = FontWeight.SemiBold)
                                Text("Wind ${w.windSpeed} m/s", color = Color(0xFFB8C7FF))
                                Text("code=${w.weatherCode}", color = Color(0xFF7F93D9), style = MaterialTheme.typography.bodySmall)
                            }
                            Spacer(Modifier.weight(1f))
                            OutlinedButton(onClick = { speak(weatherSpeakText(w)) }) { Text("Speak") }
                        }
                    }
                }
            }

            // YouTube Music
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1426))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Now Playing (YouTube Music)", color = Color.White, fontWeight = FontWeight.Medium)

                    val title = YtmState.title
                    val artist = YtmState.artist
                    val playing = YtmState.isPlaying
                    val art: Bitmap? = YtmState.albumArt

                    if (art != null) {
                        Image(
                            bitmap = art.asImageBitmap(),
                            contentDescription = "Album Art",
                            modifier = Modifier
                                .size(96.dp)
                                .clip(RoundedCornerShape(18.dp))
                        )
                    }
                    Text(title, color = Color(0xFFE6ECFF), fontWeight = FontWeight.SemiBold)
                    Text(artist, color = Color(0xFFB8C7FF))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { openNotificationAccessSettings(ctx) }) { Text("Enable Access") }
                        OutlinedButton(onClick = { YtmState.prev() }) { Text("Prev") }
                        Button(onClick = { YtmState.playPause() }) { Text(if (playing) "Pause" else "Play") }
                        OutlinedButton(onClick = { YtmState.next() }) { Text("Next") }
                    }
                }
            }

            error?.let { Text("Error: $it", color = Color(0xFFFF7A7A)) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun openNotificationAccessSettings(ctx: android.content.Context) {
    try {
        ctx.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Throwable) {
        ctx.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun getLocation(
    fused: com.google.android.gms.location.FusedLocationProviderClient,
    cb: (Result<Pair<Double, Double>>) -> Unit
) {
    try {
        fused.lastLocation
            .addOnSuccessListener { loc: Location? ->
                if (loc != null) cb(Result.success(loc.latitude to loc.longitude))
                else cb(Result.failure(IllegalStateException("Location null")))
            }
            .addOnFailureListener { e ->
                cb(Result.failure(e))
            }
    } catch (t: Throwable) {
        cb(Result.failure(t))
    }
}

private suspend fun fetchCurrentWeather(lat: Double, lon: Double): Result<CurrentWeather> = withContext(Dispatchers.IO) {
    runCatching {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,wind_speed_10m")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 10000
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(body)
        val current = json.getJSONObject("current")
        CurrentWeather(
            temperatureC = current.getDouble("temperature_2m"),
            windSpeed = current.getDouble("wind_speed_10m"),
            weatherCode = current.getInt("weather_code")
        )
    }
}

private fun weatherSpeakText(w: CurrentWeather): String {
    val desc = when (w.weatherCode) {
        0 -> "快晴"
        1, 2, 3 -> "晴れ時々くもり"
        in 45..48 -> "霧"
        in 51..67 -> "雨"
        in 71..77 -> "雪"
        in 80..82 -> "にわか雨"
        in 95..99 -> "雷雨"
        else -> "天気コード${w.weatherCode}"
    }
    return "現在の天気は、$desc。気温は${w.temperatureC.roundToInt()}度。風速は${w.windSpeed}メートル毎秒です。"
}

@Composable
private fun FuturisticWeatherIcon(code: Int) {
    val icon: ImageVector = when (code) {
        0 -> androidx.compose.material.icons.Icons.Rounded.WbSunny
        1, 2, 3 -> androidx.compose.material.icons.Icons.Rounded.Cloud
        in 45..48 -> androidx.compose.material.icons.Icons.Rounded.Cloud
        in 51..67 -> androidx.compose.material.icons.Icons.Rounded.Grain
        in 71..77 -> androidx.compose.material.icons.Icons.Rounded.AcUnit
        in 80..82 -> androidx.compose.material.icons.Icons.Rounded.Umbrella
        in 95..99 -> androidx.compose.material.icons.Icons.Rounded.Thunderstorm
        else -> androidx.compose.material.icons.Icons.Rounded.Help
    }
    Icon(imageVector = icon, contentDescription = null, tint = Color(0xFF7DF9FF), modifier = Modifier.size(42.dp))
}

@Composable
private fun OsmMapWidget(lat: Double, lon: Double, headingDeg: Float, followMode: Boolean, northUp: Boolean, roads: List<List<GeoPoint>>) {
    val ctx = LocalContext.current

    // Dark tiles (CartoDB Dark Matter) - no API key
    val darkTiles = remember {
        object : OnlineTileSourceBase(
            "CartoDBDark",
            0, 20, 256, ".png",
            arrayOf("https://a.basemaps.cartocdn.com/dark_all/",
                    "https://b.basemaps.cartocdn.com/dark_all/",
                    "https://c.basemaps.cartocdn.com/dark_all/")
        ) {
            override fun getTileURLString(aMapTileIndex: Long): String {
                return baseUrl + MapTileIndex.getZoom(aMapTileIndex) + "/" +
                    MapTileIndex.getX(aMapTileIndex) + "/" +
                    MapTileIndex.getY(aMapTileIndex) + mImageFilenameEnding
            }
        }
    }

    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF050510)),
        factory = {
            Configuration.getInstance().userAgentValue = ctx.packageName
            MapView(ctx).apply {
                setTileSource(darkTiles)
                setMultiTouchControls(true)
                minZoomLevel = 3.0
                maxZoomLevel = 20.0
                isFlingEnabled = true

                val point = GeoPoint(lat, lon)
                controller.setZoom(18.8)
                controller.setCenter(point)
                setMapOrientation(if (northUp) 0f else headingDeg)

                // Overlays: neon roads + futuristic pin
overlays.clear()

// Neon roads overlay (drawn on top of tiles, under marker)
val neon = NeonRoadOverlay()
overlays.add(neon)
setTag(R.id.tag_neon_overlay, neon)

// Futuristic pin
val marker = Marker(this).apply {
    position = point
    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
    icon = ContextCompat.getDrawable(ctx, R.drawable.ic_future_pin)
    title = "You are here"
}
overlays.add(marker)

            }
        },
        update = { mapView: MapView ->
            val point = GeoPoint(lat, lon)
            if (followMode) {
                mapView.controller.setZoom(18.8)
                mapView.controller.setCenter(point)
            }
            mapView.setMapOrientation(if (northUp) 0f else headingDeg)

// Update neon roads
(mapView.getTag(R.id.tag_neon_overlay) as? NeonRoadOverlay)?.setRoads(roads)

// Update marker position

            val marker = mapView.overlays.filterIsInstance<Marker>().firstOrNull()
            if (marker != null) {
                marker.position = point
                mapView.invalidate()
            }
        }
    )

    // Coordinate overlay (top-left)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .offset(y = (-280).dp) // place over the map area
            .padding(start = 10.dp, top = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF050510).copy(alpha = 0.55f))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text(
                text = "lat=%.5f, lon=%.5f".format(lat, lon),
                color = Color(0xFFE6ECFF),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
