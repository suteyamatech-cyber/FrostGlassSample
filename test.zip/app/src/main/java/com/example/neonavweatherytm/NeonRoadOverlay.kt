package com.example.neonavweatherytm

import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import androidx.annotation.ColorInt
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay

/**
 * TRON cyan neon roads overlay (HUD level).
 * Roads are GeoPoint polylines (from Overpass API).
 */
class NeonRoadOverlay : Overlay() {

    @Volatile private var roads: List<List<GeoPoint>> = emptyList()

    fun setRoads(newRoads: List<List<GeoPoint>>) {
        roads = newRoads
    }

    override fun draw(c: Canvas, map: MapView, shadow: Boolean) {
        if (shadow) return
        val rs = roads
        if (rs.isEmpty()) return

        val proj = map.projection
        val tmp = Point()

        // HUD-level strong TRON cyan colors
        @ColorInt val core  = 0xFFCCFFFF.toInt() // almost white cyan (readability)
        @ColorInt val glow2 = 0xFF00E5FF.toInt() // main glow
        @ColorInt val glow1 = 0xFF00A3FF.toInt() // outer atmosphere

        val z = map.zoomLevelDouble
        val zoomScale = (z / 18.8).toFloat().coerceIn(0.85f, 1.25f)
        val density = map.context.resources.displayMetrics.density

        val glow1W = 22f * density * zoomScale
        val glow2W = 14f * density * zoomScale
        val coreW  = 5f  * density * zoomScale

        val pGlow1 = paint(glow1, glow1W, blurPx = 28f, alpha = 0.30f)
        val pGlow2 = paint(glow2, glow2W, blurPx = 18f, alpha = 0.55f)
        val pCore  = paint(core,  coreW,  blurPx = 0f,  alpha = 0.95f)

        c.save()
        c.clipRect(0, 0, map.width, map.height)

        for (poly in rs) {
            if (poly.size < 2) continue
            val path = Path()

            proj.toPixels(poly[0], tmp)
            path.moveTo(tmp.x.toFloat(), tmp.y.toFloat())

            for (i in 1 until poly.size) {
                proj.toPixels(poly[i], tmp)
                path.lineTo(tmp.x.toFloat(), tmp.y.toFloat())
            }

            // 3 layers: outer -> main -> core
            c.drawPath(path, pGlow1)
            c.drawPath(path, pGlow2)
            c.drawPath(path, pCore)
        }

        c.restore()
    }

    private fun paint(@ColorInt color: Int, strokePx: Float, blurPx: Float, alpha: Float): Paint {
        return Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = strokePx
            this.color = color
            this.alpha = (255f * alpha).toInt().coerceIn(0, 255)
            if (blurPx > 0f) {
                maskFilter = BlurMaskFilter(blurPx, BlurMaskFilter.Blur.NORMAL)
            }
        }
    }
}
