package com.example.weathertalkeragent

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.JAPAN
                tts?.setSpeechRate(1.0f)
            }
        }

        setContent {
            MaterialTheme {
                WeatherAgentApp(speak = { text -> speak(text) })
            }
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "weather-agent")
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

data class CurrentWeather(
    val temperatureC: Double,
    val windSpeed: Double,
    val weatherCode: Int,
    val time: String
)

@Composable
private fun WeatherAgentApp(
    speak: (String) -> Unit
) {
    val scope = rememberCoroutineScope()

    var lat by remember { mutableStateOf("35.681236") }   // Tokyo Station
    var lon by remember { mutableStateOf("139.767125") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var weather by remember { mutableStateOf<CurrentWeather?>(null) }

    fun makeSpeech(w: CurrentWeather): String {
        val temp = w.temperatureC.roundToInt()
        val wind = w.windSpeed.roundToInt()
        val desc = weatherCodeToJa(w.weatherCode)
        return "現在の天気は、${desc}。気温は${temp}度。風は毎秒${wind}メートルくらいです。"
    }

    Surface(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Weather Talker Agent (APIキー不要)", style = MaterialTheme.typography.titleLarge)

            OutlinedTextField(
                value = lat,
                onValueChange = { lat = it },
                label = { Text("Latitude (緯度)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = lon,
                onValueChange = { lon = it },
                label = { Text("Longitude (経度)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    enabled = !loading,
                    onClick = {
                        error = null
                        loading = true
                        weather = null
                        scope.launch {
                            val result = fetchCurrentWeather(lat.trim(), lon.trim())
                            loading = false
                            result.fold(
                                onSuccess = { w -> weather = w },
                                onFailure = { e -> error = e.message ?: "Failed to fetch weather" }
                            )
                        }
                    }
                ) { Text(if (loading) "Fetching..." else "Get Weather") }

                OutlinedButton(
                    enabled = weather != null && !loading,
                    onClick = {
                        weather?.let { speak(makeSpeech(it)) }
                    }
                ) { Text("Speak") }
            }

            if (error != null) {
                AssistChip(onClick = { }, label = { Text("Error: $error") })
            }

            WeatherCard(weather)

            Divider()

            Text("かんたんエージェント", style = MaterialTheme.typography.titleMedium)
            var userText by remember { mutableStateOf("") }
            OutlinedTextField(
                value = userText,
                onValueChange = { userText = it },
                label = { Text("話しかけて（例：今日は傘いる？）") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val reply = agentReply(userText, weather)
                    speak(reply)
                },
                modifier = Modifier.align(Alignment.End)
            ) { Text("Reply & Speak") }

            Text(
                text = "※ AI（LLM）は未使用。天気情報と簡単ルールで返答します。",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun WeatherCard(weather: CurrentWeather?) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (weather == null) {
                Text("まだ天気を取得していません。")
                Text("緯度・経度を入れて Get Weather を押してください。", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("Current Weather", style = MaterialTheme.typography.titleMedium)
                Text("Time: ${weather.time}")
                Text("Temp: ${weather.temperatureC} °C")
                Text("Wind: ${weather.windSpeed} m/s")
                Text("Weather: ${weatherCodeToJa(weather.weatherCode)} (code=${weather.weatherCode})")
            }
        }
    }
}

/** Open-Meteo (no API key) */
private suspend fun fetchCurrentWeather(lat: String, lon: String): Result<CurrentWeather> = withContext(Dispatchers.IO) {
    runCatching {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
        }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) error("HTTP $code: $body")

        val json = JSONObject(body)
        val cw = json.getJSONObject("current_weather")
        CurrentWeather(
            temperatureC = cw.getDouble("temperature"),
            windSpeed = cw.getDouble("windspeed"),
            weatherCode = cw.getInt("weathercode"),
            time = cw.getString("time")
        )
    }
}

private fun weatherCodeToJa(code: Int): String = when (code) {
    0 -> "快晴"
    1, 2, 3 -> "晴れ（時々くもり）"
    45, 48 -> "霧"
    51, 53, 55 -> "霧雨"
    61, 63, 65 -> "雨"
    66, 67 -> "凍雨"
    71, 73, 75 -> "雪"
    80, 81, 82 -> "にわか雨"
    95 -> "雷雨"
    96, 99 -> "ひょうを伴う雷雨"
    else -> "不明"
}

private fun agentReply(user: String, w: CurrentWeather?): String {
    val u = user.trim()
    if (u.isEmpty()) return "何か聞いてください。たとえば「今日傘いる？」のように。"
    if (w == null) return "まずは Get Weather で天気を取得してから聞いてください。"

    val code = w.weatherCode
    val isRainy = code in listOf(61, 63, 65, 80, 81, 82, 95, 96, 99)
    val isSnowy = code in listOf(71, 73, 75)

    return when {
        u.contains("傘") || u.contains("雨") ->
            if (isRainy) "雨っぽいです。傘を持っていきましょう。" else "いまのところ大きな雨ではなさそうです。"
        u.contains("寒") || u.contains("気温") ->
            if (w.temperatureC < 10) "けっこう寒いです。上着があると安心です。" else "極端には寒くないです。"
        u.contains("雪") ->
            if (isSnowy) "雪の可能性があります。足元に注意してください。" else "いまのところ雪の気配は薄いです。"
        else -> "現在の天気は ${weatherCodeToJa(code)}、気温は ${w.temperatureC.roundToInt()}度です。"
    }
}
