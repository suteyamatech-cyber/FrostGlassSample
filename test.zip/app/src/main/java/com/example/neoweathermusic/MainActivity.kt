package com.example.neoweathermusic

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private var hasLocationPermission by mutableStateOf(false)

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val fine = result[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarse = result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        hasLocationPermission = fine || coarse
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hasLocationPermission = checkLocationPermission()

        setContent {
            MaterialTheme {
                NeoScreen(
                    hasLocationPermission = hasLocationPermission,
                    onRequestPermission = {
                        requestPermissions.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    },
                    getLocation = { callback -> getCurrentLatLon(callback) }
                )
            }
        }
    }

    private fun checkLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLatLon(callback: (Result<Pair<Double, Double>>) -> Unit) {
        if (!checkLocationPermission()) {
            callback(Result.failure(IllegalStateException("Location permission not granted")))
            return
        }
        val client = LocationServices.getFusedLocationProviderClient(this)
        client.lastLocation
            .addOnSuccessListener { loc ->
                if (loc != null) callback(Result.success(loc.latitude to loc.longitude))
                else callback(Result.failure(IllegalStateException("Location is null (try again)")))
            }
            .addOnFailureListener { e -> callback(Result.failure(e)) }
    }
}

data class CurrentWeather(
    val temperatureC: Double,
    val windSpeed: Double,
    val weatherCode: Int,
    val time: String
)

@Composable
fun NeoScreen(
    hasLocationPermission: Boolean,
    onRequestPermission: () -> Unit,
    getLocation: ((Result<Pair<Double, Double>>) -> Unit) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val inf = rememberInfiniteTransition(label = "glow")
    val glow by inf.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.65f,
        animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Reverse),
        label = "glowAnim"
    )

    var status by remember { mutableStateOf("Ready") }
    var latLon by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var weather by remember { mutableStateOf<CurrentWeather?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // Audio player (sample stream)
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            val url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
            setMediaItem(MediaItem.fromUri(url))
            prepare()
        }
    }
    var playing by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF050510), Color(0xFF0B1030), Color(0xFF001A2D))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Neo Weather Agent",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Text(
                text = "GPS自動取得 / 天気表示 / 音楽再生（サンプル）",
                color = Color(0xFFB8C7FF)
            )

            NeoCard(glow) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Location", color = Color.White, fontWeight = FontWeight.Medium)
                    Text(
                        text = latLon?.let { "lat=${it.first}, lon=${it.second}" } ?: "Not acquired",
                        color = Color(0xFFE6ECFF)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                error = null
                                if (!hasLocationPermission) {
                                    onRequestPermission()
                                    status = "Requesting permission..."
                                } else {
                                    status = "Getting location..."
                                    getLocation { res ->
                                        res.onSuccess {
                                            latLon = it
                                            status = "Location OK"
                                        }.onFailure { e ->
                                            error = e.message
                                            status = "Location failed"
                                        }
                                    }
                                }
                            }
                        ) { Text("Get GPS") }

                        OutlinedButton(
                            enabled = latLon != null && !loading,
                            onClick = {
                                val ll = latLon ?: return@OutlinedButton
                                loading = true
                                status = "Fetching weather..."
                                scope.launch {
                                    val r = fetchCurrentWeather(ll.first, ll.second)
                                    loading = false
                                    r.fold(
                                        onSuccess = {
                                            weather = it
                                            status = "Weather OK"
                                        },
                                        onFailure = { e ->
                                            error = e.message ?: "Weather failed"
                                            status = "Weather failed"
                                        }
                                    )
                                }
                            }
                        ) { Text(if (loading) "..." else "Get Weather") }
                    }
                }
            }

            NeoCard(glow) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Weather", color = Color.White, fontWeight = FontWeight.Medium)
                    if (weather == null) {
                        Text("No weather yet.", color = Color(0xFFE6ECFF))
                    } else {
                        val w = weather!!
                        Text("Time: ${w.time}", color = Color(0xFFE6ECFF))
                        Text("Temp: ${w.temperatureC} °C", color = Color(0xFFE6ECFF))
                        Text("Wind: ${w.windSpeed} m/s", color = Color(0xFFE6ECFF))
                        Text("Sky: ${weatherCodeToJa(w.weatherCode)}", color = Color(0xFFE6ECFF))
                    }
                }
            }

            NeoCard(glow) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Music", color = Color.White, fontWeight = FontWeight.Medium)
                    Text("サンプル音源をストリーミング再生（Spotify連携ではありません）", color = Color(0xFFB8C7FF))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            playing = true
                            player.playWhenReady = true
                        }) { Text("Play") }
                        Spacer(Modifier.width(12.dp))
                        OutlinedButton(onClick = {
                            playing = false
                            player.playWhenReady = false
                        }) { Text("Pause") }
                        Spacer(Modifier.width(12.dp))
                        Text(if (playing) "Playing" else "Paused", color = Color(0xFFE6ECFF))
                    }
                }
            }

            if (error != null) {
                Text("Error: $error", color = Color(0xFFFFA3A3))
            }
            Text("Status: $status", color = Color(0xFFE6ECFF))
        }
    }
}

@Composable
private fun NeoCard(glow: Float, content: @Composable () -> Unit) {
    val bg = Color(0xFF0D1638).copy(alpha = 0.55f)
    Card(
        colors = CardDefaults.cardColors(containerColor = bg),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF68E1FD).copy(alpha = glow * 0.20f),
                            Color(0xFF9B8CFF).copy(alpha = glow * 0.12f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp)
        ) {
            content()
        }
    }
}

/** Open-Meteo (no API key) */
private suspend fun fetchCurrentWeather(lat: Double, lon: Double): Result<CurrentWeather> = withContext(Dispatchers.IO) {
    runCatching {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
        }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader()
            .use { it.readText() }
        if (code !in 200..299) error("HTTP $code: $body")

        val json = JSONObject(body)
        val cw = json.getJSONObject("current_weather")
        CurrentWeather(
            temperatureC = cw.getDouble("temperature"),
            windSpeed = cw.getDouble("windspeed"),
            weatherCode = cw.getInt("weathercode"),
            time = cw.getString("time")
        )
    }
}

private fun weatherCodeToJa(code: Int): String = when (code) {
    0 -> "快晴"
    1, 2, 3 -> "晴れ（時々くもり）"
    45, 48 -> "霧"
    51, 53, 55 -> "霧雨"
    61, 63, 65 -> "雨"
    71, 73, 75 -> "雪"
    80, 81, 82 -> "にわか雨"
    95 -> "雷雨"
    96, 99 -> "ひょうを伴う雷雨"
    else -> "不明"
}
