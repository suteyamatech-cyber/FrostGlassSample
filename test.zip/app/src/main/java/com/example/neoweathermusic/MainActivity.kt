package com.example.neoweathermusic

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.clip
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.asPaddingValues

class MainActivity : ComponentActivity() {

    private var hasLocationPermission by mutableStateOf(false)
    private var tts: TextToSpeech? = null

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val fine = result[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarse = result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        hasLocationPermission = fine || coarse
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hasLocationPermission = checkLocationPermission()

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.JAPAN
                tts?.setSpeechRate(1.0f)
            }
        }

        setContent {
            MaterialTheme {
                NeoScreen(
                    hasLocationPermission = hasLocationPermission,
                    onRequestPermission = {
                        requestPermissions.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    },
                    getLocation = { callback -> getCurrentLatLon(callback) },
                    speak = { text -> speak(text) }
                )
            }
        }
    }

    private fun checkLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    private fun getCurrentLatLon(callback: (Result<Pair<Double, Double>>) -> Unit) {
        if (!checkLocationPermission()) {
            callback(Result.failure(IllegalStateException("Location permission not granted")))
            return
        }
        val client = LocationServices.getFusedLocationProviderClient(this)
        client.lastLocation
            .addOnSuccessListener { loc ->
                if (loc != null) callback(Result.success(loc.latitude to loc.longitude))
                else callback(Result.failure(IllegalStateException("Location is null (try again)")))
            }
            .addOnFailureListener { e -> callback(Result.failure(e)) }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "neo-weather")
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

data class CurrentWeather(
    val temperatureC: Double,
    val windSpeed: Double,
    val weatherCode: Int,
    val time: String
)

@Composable
fun NeoScreen(
    hasLocationPermission: Boolean,
    onRequestPermission: () -> Unit,
    getLocation: ((Result<Pair<Double, Double>>) -> Unit) -> Unit,
    speak: (String) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val inf = rememberInfiniteTransition(label = "glow")
    val glow by inf.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.70f,
        animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Reverse),
        label = "glowAnim"
    )

    var status by remember { mutableStateOf("Ready") }
    var latLon by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var weather by remember { mutableStateOf<CurrentWeather?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // Sample music player (stream)
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            val url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
            setMediaItem(MediaItem.fromUri(url))
            prepare()
        }
    }
    var playing by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    fun speakWeather() {
        val w = weather ?: run {
            speak("まず位置情報と天気を取得してください。")
            return
        }
        val desc = weatherCodeToJa(w.weatherCode)
        val temp = w.temperatureC.roundToInt()
        val wind = w.windSpeed.roundToInt()
        speak("現在の天気は${desc}。気温は${temp}度。風は毎秒${wind}メートルくらいです。")
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF050510), Color(0xFF0B1030), Color(0xFF001A2D))
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                // ✅ avoid status bar overlap
                .padding(WindowInsets.systemBars.asPaddingValues())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Neo Weather Agent",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Text(
                text = "OSM Map（APIキー不要） / Spotify(簡易) / 未来アイコン + TTS / GPS自動取得",
                color = Color(0xFFB8C7FF)
            )

            NeoCard(glow) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Location", color = Color.White, fontWeight = FontWeight.Medium)
                    Text(
                        text = latLon?.let { "lat=${it.first}, lon=${it.second}" } ?: "Not acquired",
                        color = Color(0xFFE6ECFF)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                error = null
                                if (!hasLocationPermission) {
                                    onRequestPermission()
                                    status = "Requesting permission..."
                                } else {
                                    status = "Getting location..."
                                    getLocation { res ->
                                        res.onSuccess {
                                            latLon = it
                                            status = "Location OK"
                                        }.onFailure { e ->
                                            error = e.message
                                            status = "Location failed"
                                        }
                                    }
                                }
                            }
                        ) { Text("Get GPS") }

                        OutlinedButton(
                            enabled = latLon != null && !loading,
                            onClick = {
                                val ll = latLon ?: return@OutlinedButton
                                loading = true
                                status = "Fetching weather..."
                                scope.launch {
                                    val r = fetchCurrentWeather(ll.first, ll.second)
                                    loading = false
                                    r.fold(
                                        onSuccess = {
                                            weather = it
                                            status = "Weather OK"
                                        },
                                        onFailure = { e ->
                                            error = e.message ?: "Weather failed"
                                            status = "Weather failed"
                                        }
                                    )
                                }
                            }
                        ) { Text(if (loading) "..." else "Get Weather") }
                    }

                    val ll = latLon
                    if (ll != null) {
                        OsmMapWidget(lat = ll.first, lon = ll.second)
                    } else {
                        Text("Map: GPS取得後に表示します（APIキー不要）", color = Color(0xFFB8C7FF))
                    }
                }
            }

            NeoCard(glow) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Weather", color = Color.White, fontWeight = FontWeight.Medium)
                    if (weather == null) {
                        Text("No weather yet.", color = Color(0xFFE6ECFF))
                    } else {
                        val w = weather!!
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FuturisticWeatherIcon(
                                code = w.weatherCode,
                                glow = glow,
                                modifier = Modifier.size(60.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("${weatherCodeToJa(w.weatherCode)}", color = Color(0xFFE6ECFF))
                                Text("${w.temperatureC} °C / wind ${w.windSpeed} m/s", color = Color(0xFFE6ECFF))
                                Text("time ${w.time}", color = Color(0xFFB8C7FF))
                            }
                        }
                        OutlinedButton(onClick = { speakWeather() }) { Text("Speak (TTS)") }
                    }
                }
            }

            NeoCard(glow) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Music", color = Color.White, fontWeight = FontWeight.Medium)
                    Text("① サンプル音源再生 ② Spotifyアプリ起動（簡易連携）", color = Color(0xFFB8C7FF))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            playing = true
                            player.playWhenReady = true
                        }) { Text("Play Sample") }
                        Spacer(Modifier.width(12.dp))
                        OutlinedButton(onClick = {
                            playing = false
                            player.playWhenReady = false
                        }) { Text("Pause") }
                        Spacer(Modifier.width(12.dp))
                        Text(if (playing) "Playing" else "Paused", color = Color(0xFFE6ECFF))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { openSpotify(ctx, "spotify:") }) { Text("Open Spotify") }
                        OutlinedButton(onClick = { openSpotify(ctx, "spotify:playlist:37i9dQZF1DXcBWIGoYBM5M") }) { Text("Open Playlist") }
                    }

                    Text(
                        "※ 本格Spotify連携（ログイン/再生制御）はSDK＋Client IDが必要です。いまは「アプリ起動」まで。",
                        color = Color(0xFFB8C7FF),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            if (error != null) {
                Text("Error: $error", color = Color(0xFFFFA3A3))
            }
            Text("Status: $status", color = Color(0xFFE6ECFF))
        }
    }
}

@Composable
private fun OsmMapWidget(lat: Double, lon: Double) {
    val ctx = LocalContext.current
    val point = remember(lat, lon) { GeoPoint(lat, lon) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Map (OpenStreetMap)", color = Color.White, fontWeight = FontWeight.Medium)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0D1638).copy(alpha = 0.35f))
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = {
                    // osmdroid requires userAgent to avoid being blocked by tile servers
                    Configuration.getInstance().userAgentValue = ctx.packageName

                    MapView(ctx).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(15.0)
                        controller.setCenter(point)

                        val marker = Marker(this).apply {
                            position = point
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                            title = "You are here"
                        }
                        overlays.add(marker)
                    }
                },
                update = { mapView ->
                    mapView.controller.setCenter(point)
                    // Update the first Marker if present
                    val marker = mapView.overlays.firstOrNull { it is Marker } as? Marker
                    if (marker != null) {
                        marker.position = point
                        mapView.invalidate()
                    }
                }
            )
        }
    }
}

@Composable
private fun NeoCard(glow: Float, content: @Composable () -> Unit) {
    val bg = Color(0xFF0D1638).copy(alpha = 0.55f)
    Card(
        colors = CardDefaults.cardColors(containerColor = bg),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF68E1FD).copy(alpha = glow * 0.22f),
                            Color(0xFF9B8CFF).copy(alpha = glow * 0.14f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp)
        ) { content() }
    }
}

private fun openSpotify(ctx: android.content.Context, uri: String) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
        ctx.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        val web = when {
            uri.startsWith("spotify:playlist:") -> {
                val id = uri.removePrefix("spotify:playlist:")
                "https://open.spotify.com/playlist/$id"
            }
            uri.startsWith("spotify:track:") -> {
                val id = uri.removePrefix("spotify:track:")
                "https://open.spotify.com/track/$id"
            }
            else -> "https://open.spotify.com/"
        }
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(web)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }
}

/** Open-Meteo (no API key) */
private suspend fun fetchCurrentWeather(lat: Double, lon: Double): Result<CurrentWeather> = withContext(Dispatchers.IO) {
    runCatching {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
        }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader()
            .use { it.readText() }
        if (code !in 200..299) error("HTTP $code: $body")

        val json = JSONObject(body)
        val cw = json.getJSONObject("current_weather")
        CurrentWeather(
            temperatureC = cw.getDouble("temperature"),
            windSpeed = cw.getDouble("windspeed"),
            weatherCode = cw.getInt("weathercode"),
            time = cw.getString("time")
        )
    }
}

private fun weatherCodeToJa(code: Int): String = when (code) {
    0 -> "快晴"
    1, 2, 3 -> "晴れ（時々くもり）"
    45, 48 -> "霧"
    51, 53, 55 -> "霧雨"
    61, 63, 65 -> "雨"
    71, 73, 75 -> "雪"
    80, 81, 82 -> "にわか雨"
    95 -> "雷雨"
    96, 99 -> "ひょうを伴う雷雨"
    else -> "不明"
}

// ---------- Futuristic icon (no assets, pure Canvas) ----------
@Composable
private fun FuturisticWeatherIcon(code: Int, glow: Float, modifier: Modifier = Modifier) {
    val c1 = Color(0xFF68E1FD)
    val c2 = Color(0xFF9B8CFF)
    val stroke = Stroke(width = 6f, cap = StrokeCap.Round)

    Canvas(modifier = modifier) {
        val s = min(size.width, size.height)
        val center = Offset(size.width / 2f, size.height / 2f)

        // Outer halo
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(c1.copy(alpha = glow * 0.35f), Color.Transparent),
                center = center,
                radius = s * 0.7f
            ),
            radius = s * 0.48f,
            center = center
        )

        // Base ring
        drawCircle(color = c2.copy(alpha = 0.35f), radius = s * 0.42f, center = center, style = Stroke(width = 2.5f))

        when (iconKind(code)) {
            IconKind.SUN -> drawSun(center, s, c1, c2)
            IconKind.CLOUD -> drawCloud(center, s, c1, c2)
            IconKind.RAIN -> { drawCloud(center, s, c1, c2); drawRain(center, s, c1) }
            IconKind.SNOW -> { drawCloud(center, s, c1, c2); drawSnow(center, s, c1) }
            IconKind.STORM -> { drawCloud(center, s, c1, c2); drawBolt(center, s, c2); drawRain(center, s, c1) }
            IconKind.FOG -> { drawFog(center, s, c1, c2) }
            IconKind.UNKNOWN -> drawQuestion(center, s, c1)
        }

        fun neonLine(p1: Offset, p2: Offset, col: Color) {
            drawLine(col.copy(alpha = 0.9f), p1, p2, strokeWidth = 5.5f, cap = StrokeCap.Round)
            drawLine(col.copy(alpha = glow * 0.55f), p1, p2, strokeWidth = 11f, cap = StrokeCap.Round)
        }

        // Small accent crosshair
        neonLine(Offset(center.x, center.y - s * 0.50f), Offset(center.x, center.y - s * 0.44f), c2)
        neonLine(Offset(center.x, center.y + s * 0.44f), Offset(center.x, center.y + s * 0.50f), c2)
    }
}

private enum class IconKind { SUN, CLOUD, RAIN, SNOW, STORM, FOG, UNKNOWN }

private fun iconKind(code: Int): IconKind = when (code) {
    0 -> IconKind.SUN
    1, 2, 3 -> IconKind.CLOUD
    45, 48 -> IconKind.FOG
    51, 53, 55, 61, 63, 65, 80, 81, 82 -> IconKind.RAIN
    71, 73, 75 -> IconKind.SNOW
    95, 96, 99 -> IconKind.STORM
    else -> IconKind.UNKNOWN
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSun(center: Offset, s: Float, c1: Color, c2: Color) {
    val r = s * 0.16f
    drawCircle(c1.copy(alpha = 0.85f), r, center)
    drawCircle(c1.copy(alpha = 0.25f), r * 1.8f, center)
    for (i in 0 until 8) {
        val ang = (Math.PI * 2.0 * i / 8.0).toFloat()
        val a = Offset(
            x = center.x + kotlin.math.cos(ang) * (s * 0.26f),
            y = center.y + kotlin.math.sin(ang) * (s * 0.26f)
        )
        val b = Offset(
            x = center.x + kotlin.math.cos(ang) * (s * 0.34f),
            y = center.y + kotlin.math.sin(ang) * (s * 0.34f)
        )
        drawLine(c2.copy(alpha = 0.9f), a, b, strokeWidth = 6f, cap = StrokeCap.Round)
        drawLine(c2.copy(alpha = 0.25f), a, b, strokeWidth = 12f, cap = StrokeCap.Round)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCloud(center: Offset, s: Float, c1: Color, c2: Color) {
    val w = s * 0.55f
    val h = s * 0.30f
    val top = center.y - s * 0.06f

    val path = Path().apply {
        moveTo(center.x - w * 0.45f, top + h * 0.55f)
        cubicTo(center.x - w * 0.55f, top + h * 0.10f, center.x - w * 0.15f, top - h * 0.05f, center.x - w * 0.10f, top + h * 0.25f)
        cubicTo(center.x - w * 0.02f, top - h * 0.30f, center.x + w * 0.18f, top - h * 0.10f, center.x + w * 0.10f, top + h * 0.25f)
        cubicTo(center.x + w * 0.30f, top - h * 0.10f, center.x + w * 0.55f, top + h * 0.15f, center.x + w * 0.40f, top + h * 0.55f)
        lineTo(center.x - w * 0.45f, top + h * 0.55f)
        close()
    }

    drawPath(path, c1.copy(alpha = 0.18f))
    drawPath(path, c1.copy(alpha = 0.85f), style = Stroke(width = 6f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
    drawPath(path, c2.copy(alpha = 0.20f), style = Stroke(width = 12f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRain(center: Offset, s: Float, c1: Color) {
    val y0 = center.y + s * 0.18f
    val y1 = center.y + s * 0.34f
    val xs = listOf(-0.16f, 0.0f, 0.16f)
    for (x in xs) {
        val a = Offset(center.x + s * x, y0)
        val b = Offset(center.x + s * (x - 0.04f), y1)
        drawLine(c1.copy(alpha = 0.9f), a, b, strokeWidth = 6f, cap = StrokeCap.Round)
        drawLine(c1.copy(alpha = 0.25f), a, b, strokeWidth = 12f, cap = StrokeCap.Round)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSnow(center: Offset, s: Float, c1: Color) {
    val y = center.y + s * 0.26f
    val xs = listOf(-0.16f, 0.0f, 0.16f)
    for (x in xs) {
        val p = Offset(center.x + s * x, y)
        drawLine(c1.copy(alpha = 0.9f), Offset(p.x - s*0.05f, p.y), Offset(p.x + s*0.05f, p.y), strokeWidth = 5.5f, cap = StrokeCap.Round)
        drawLine(c1.copy(alpha = 0.9f), Offset(p.x, p.y - s*0.05f), Offset(p.x, p.y + s*0.05f), strokeWidth = 5.5f, cap = StrokeCap.Round)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBolt(center: Offset, s: Float, c2: Color) {
    val p = Path().apply {
        moveTo(center.x + s*0.02f, center.y + s*0.10f)
        lineTo(center.x - s*0.06f, center.y + s*0.28f)
        lineTo(center.x + s*0.02f, center.y + s*0.28f)
        lineTo(center.x - s*0.02f, center.y + s*0.44f)
        lineTo(center.x + s*0.10f, center.y + s*0.22f)
        lineTo(center.x + s*0.02f, center.y + s*0.22f)
        close()
    }
    drawPath(p, c2.copy(alpha = 0.85f))
    drawPath(p, c2.copy(alpha = 0.25f), style = Stroke(width = 10f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawFog(center: Offset, s: Float, c1: Color, c2: Color) {
    val ys = listOf(-0.10f, 0.02f, 0.14f)
    for ((i, yy) in ys.withIndex()) {
        val a = Offset(center.x - s*0.22f, center.y + s*yy)
        val b = Offset(center.x + s*0.22f, center.y + s*yy)
        val col = if (i % 2 == 0) c1 else c2
        drawLine(col.copy(alpha = 0.9f), a, b, strokeWidth = 6f, cap = StrokeCap.Round)
        drawLine(col.copy(alpha = 0.20f), a, b, strokeWidth = 12f, cap = StrokeCap.Round)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawQuestion(center: Offset, s: Float, c1: Color) {
    val w = s*0.18f
    drawLine(c1.copy(alpha = 0.9f), Offset(center.x - w, center.y - s*0.10f), Offset(center.x, center.y - s*0.18f), strokeWidth = 6f, cap = StrokeCap.Round)
    drawLine(c1.copy(alpha = 0.9f), Offset(center.x, center.y - s*0.18f), Offset(center.x + w, center.y - s*0.10f), strokeWidth = 6f, cap = StrokeCap.Round)
    drawLine(c1.copy(alpha = 0.9f), Offset(center.x + w, center.y - s*0.10f), Offset(center.x, center.y + s*0.05f), strokeWidth = 6f, cap = StrokeCap.Round)
    drawCircle(c1.copy(alpha = 0.9f), radius = s*0.03f, center = Offset(center.x, center.y + s*0.18f))
}
