package com.example.neoweathermusic

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Spotify integration WITHOUT API keys:
 * - Uses Notification Listener permission to access active MediaSession(s).
 * - Reads Spotify MediaSession metadata (title/artist) and playback state.
 * - Provides basic transport controls (play/pause/next/prev).
 *
 * User must enable Notification Access for this app in system settings.
 */
class SpotifyNotificationListener : NotificationListenerService() {

    private fun parseSpotifyNotification(sbn: StatusBarNotification) {
        try {
            val n = sbn.notification ?: return
            val extras = n.extras ?: return
            val title = extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
            // Spotify usually sets: title = song, text = artist (or "artist • album")
            if (title.isNotBlank()) {
                SpotifyState.connected = true
                SpotifyState.title = title
                SpotifyState.artist = text
            }
        } catch (_: Throwable) { }
    }


    override fun onListenerConnected() {
        super.onListenerConnected()
        connectToSpotifyController()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
    if (sbn.packageName == SPOTIFY_PKG) {
        // Update from notification (most reliable across devices)
        parseSpotifyNotification(sbn)
        // Also try MediaSession for transport controls if available
        connectToSpotifyController()
    }
}

    private fun connectToSpotifyController() {
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, SpotifyNotificationListener::class.java)
            val controllers = msm.getActiveSessions(component)

            val spotify = controllers.firstOrNull { it.packageName == SPOTIFY_PKG }
            if (spotify == null) {
                SpotifyState.setDisconnected()
                return
            }
            SpotifyState.attach(spotify)
        } catch (e: Throwable) {
            Log.w("SpotifyNL", "connectToSpotifyController failed", e)
            SpotifyState.setDisconnected()
        }
    }

    companion object {
        private const val SPOTIFY_PKG = "com.spotify.music"
    }
}

object SpotifyState {
    @Volatile var connected: Boolean = false
    @Volatile var title: String = "Not connected"
    @Volatile var artist: String = ""
    @Volatile var isPlaying: Boolean = false
        private set

    @Volatile private var controller: MediaController? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            val t = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            val a = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
            if (t.isNotBlank()) title = t
            artist = a
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            isPlaying = state?.state == PlaybackState.STATE_PLAYING
        }
    }

    fun attach(c: MediaController) {
        try {
            controller?.unregisterCallback(callback)
        } catch (_: Throwable) {}

        controller = c
        connected = true

        // Initial snapshot
        val md = c.metadata
        val ps = c.playbackState
        title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Spotify"
        artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        isPlaying = ps?.state == PlaybackState.STATE_PLAYING

        c.registerCallback(callback)
    }

    fun setDisconnected() {
        try {
            controller?.unregisterCallback(callback)
        } catch (_: Throwable) {}
        controller = null
        connected = false
        title = "Not connected"
        artist = ""
        isPlaying = false
    }

    fun playPause() {
        val c = controller ?: return
        val tc = c.transportControls
        if (isPlaying) tc.pause() else tc.play()
    }

    fun next() {
        controller?.transportControls?.skipToNext()
    }

    fun prev() {
        controller?.transportControls?.skipToPrevious()
    }
}
