package com.example.neoweathermusic

import android.content.ComponentName
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.support.v4.media.MediaMetadataCompat
import android.util.Log
import androidx.media.session.MediaButtonReceiver
import androidx.media.session.MediaControllerCompat

/**
 * Spotify integration WITHOUT API keys:
 * - Uses Notification Listener permission to access active MediaSession(s).
 * - Grabs Spotify's MediaSession metadata and playback state.
 * - Provides basic transport controls (play/pause/next/prev).
 *
 * User must enable Notification Access for this app in system settings.
 */
class SpotifyNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        connectToSpotifyController()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // If Spotify posts a new notification, try (re)connecting
        if (sbn.packageName == SPOTIFY_PKG) {
            connectToSpotifyController()
        }
    }

    private fun connectToSpotifyController() {
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, SpotifyNotificationListener::class.java)
            val controllers = msm.getActiveSessions(component)

            val spotify = controllers.firstOrNull { it.packageName == SPOTIFY_PKG }
            if (spotify == null) {
                SpotifyState.setDisconnected()
                return
            }

            val compat = MediaControllerCompat(this, spotify.sessionToken)
            SpotifyState.attach(compat)
        } catch (e: Throwable) {
            Log.w("SpotifyNL", "connectToSpotifyController failed", e)
            SpotifyState.setDisconnected()
        }
    }

    companion object {
        private const val SPOTIFY_PKG = "com.spotify.music"
    }
}

object SpotifyState {
    @Volatile var connected: Boolean = false
        private set
    @Volatile var title: String = "Not connected"
        private set
    @Volatile var artist: String = ""
        private set
    @Volatile var isPlaying: Boolean = false
        private set

    @Volatile private var controller: MediaControllerCompat? = null

    private val callback = object : MediaControllerCompat.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadataCompat?) {
            val t = metadata?.getString(MediaMetadataCompat.METADATA_KEY_TITLE) ?: ""
            val a = metadata?.getString(MediaMetadataCompat.METADATA_KEY_ARTIST) ?: ""
            title = if (t.isNotBlank()) t else title
            artist = a
        }

        override fun onPlaybackStateChanged(state: android.support.v4.media.session.PlaybackStateCompat?) {
            isPlaying = state?.state == android.support.v4.media.session.PlaybackStateCompat.STATE_PLAYING
        }
    }

    fun attach(c: MediaControllerCompat) {
        try {
            controller?.unregisterCallback(callback)
        } catch (_: Throwable) {}
        controller = c
        connected = true

        // Initial snapshot
        val md = c.metadata
        val ps = c.playbackState
        title = md?.getString(MediaMetadataCompat.METADATA_KEY_TITLE) ?: "Spotify"
        artist = md?.getString(MediaMetadataCompat.METADATA_KEY_ARTIST) ?: ""
        isPlaying = ps?.state == android.support.v4.media.session.PlaybackStateCompat.STATE_PLAYING

        c.registerCallback(callback)
    }

    fun setDisconnected() {
        try {
            controller?.unregisterCallback(callback)
        } catch (_: Throwable) {}
        controller = null
        connected = false
        title = "Not connected"
        artist = ""
        isPlaying = false
    }

    fun playPause() {
        val c = controller ?: return
        val tc = c.transportControls
        if (isPlaying) tc.pause() else tc.play()
    }

    fun next() {
        controller?.transportControls?.skipToNext()
    }

    fun prev() {
        controller?.transportControls?.skipToPrevious()
    }
}
