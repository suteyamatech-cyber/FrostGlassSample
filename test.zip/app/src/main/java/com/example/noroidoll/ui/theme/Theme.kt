package com.example.noroidoll.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = darkColorScheme(
    primary = Color(0xFF8E2A2A),
    secondary = Color(0xFFB89B7A),
    tertiary = Color(0xFF6A0C0C),
    background = Color(0xFF050505),
    surface = Color(0xFF0E0B0B),
    onPrimary = Color(0xFFFFF2F2),
    onBackground = Color(0xFFE6D9CA),
    onSurface = Color(0xFFE6D9CA)
)

@Composable
fun NoroiDollTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Colors,
        content = content
    )
}
