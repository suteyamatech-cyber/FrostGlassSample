package com.example.noroidoll

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.noroidoll.ui.theme.NoroiDollTheme
import kotlin.math.min
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NoroiDollTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF050505)) {
                    NoroiApp()
                }
            }
        }
    }
}

data class NailMark(
    val xRatio: Float,
    val yRatio: Float,
    val rotation: Float,
    val bloodSeed: Float
)

@Composable
fun NoroiApp() {
    val context = LocalContext.current
    val nails = remember { mutableStateListOf<NailMark>() }
    var selectedFace by remember { mutableStateOf<Uri?>(null) }
    var faceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        selectedFace = uri
        faceBitmap = uri?.let { loadBitmap(context, it) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .padding(horizontal = 14.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "のろいの藁人形",
            style = MaterialTheme.typography.headlineSmall,
            color = Color(0xFFE7D9C7),
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "藁人形をタップして釘を打ち込む。顔写真も貼り付け可能。",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFFBDAE9C)
        )

        StrawDollBoard(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            selectedFace = selectedFace,
            faceBitmap = faceBitmap,
            nails = nails,
            onAddNail = { xRatio, yRatio ->
                nails.add(
                    NailMark(
                        xRatio = xRatio.coerceIn(0.08f, 0.92f),
                        yRatio = yRatio.coerceIn(0.08f, 0.92f),
                        rotation = Random.nextFloat() * 28f - 14f,
                        bloodSeed = Random.nextFloat()
                    )
                )
                playGroan(context)
                vibrate(context)
            }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A1616))
            ) {
                Text("顔写真を選ぶ")
            }
            Button(
                onClick = {
                    nails.clear()
                    selectedFace = null
                    faceBitmap = null
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF252525))
            ) {
                Text("リセット")
            }
        }

        Text(
            text = "刺した釘: ${nails.size}本",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = Color(0xFFE0D0C0),
            style = MaterialTheme.typography.titleMedium
        )
    }
}

@Composable
private fun StrawDollBoard(
    modifier: Modifier = Modifier,
    selectedFace: Uri?,
    faceBitmap: Bitmap?,
    nails: List<NailMark>,
    onAddNail: (Float, Float) -> Unit
) {
    var boardSize by remember { mutableStateOf(IntSize.Zero) }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF110A0A))
            .onSizeChanged { boardSize = it }
            .pointerInput(boardSize) {
                detectTapGestures { p ->
                    if (boardSize.width > 0 && boardSize.height > 0) {
                        onAddNail(p.x / boardSize.width.toFloat(), p.y / boardSize.height.toFloat())
                    }
                }
            }
            .padding(12.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp))
                .background(Color.Black)
                .align(Alignment.Center)
        ) {

            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFF060606), Color(0xFF1A0E0A), Color(0xFF040404))
                )
            )

            repeat(7) { i ->
                val y = size.height * (0.16f + i * 0.12f)
                drawLine(
                    color = Color(0x33FFAA66),
                    start = Offset(0f, y),
                    end = Offset(size.width, y + Random(i).nextInt(-20, 20)),
                    strokeWidth = 2f
                )
            }

            val moonRadius = size.minDimension * 0.1f
            drawCircle(
                color = Color(0x22DDD8FF),
                radius = moonRadius,
                center = Offset(size.width * 0.82f, size.height * 0.16f)
            )

            val toriiBottom = size.height * 0.28f
            val toriiWidth = size.width * 0.32f
            val toriiX = size.width * 0.5f
            drawLine(Color(0x44110000), Offset(toriiX - toriiWidth / 2, toriiBottom), Offset(toriiX - toriiWidth / 2, toriiBottom + 120f), 18f, cap = StrokeCap.Round)
            drawLine(Color(0x44110000), Offset(toriiX + toriiWidth / 2, toriiBottom), Offset(toriiX + toriiWidth / 2, toriiBottom + 120f), 18f, cap = StrokeCap.Round)
            drawLine(Color(0x66220000), Offset(toriiX - toriiWidth * 0.7f, toriiBottom), Offset(toriiX + toriiWidth * 0.7f, toriiBottom), 22f, cap = StrokeCap.Round)
            drawLine(Color(0x551A0B0B), Offset(toriiX - toriiWidth * 0.55f, toriiBottom + 32f), Offset(toriiX + toriiWidth * 0.55f, toriiBottom + 32f), 14f, cap = StrokeCap.Round)

            val dollCenterX = size.width * 0.5f
            val headCenter = Offset(dollCenterX, size.height * 0.22f)
            val headRadius = min(size.width, size.height) * 0.11f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFFE2C28A), Color(0xFF7A5A33), Color(0xFF3A2616)),
                    center = headCenter,
                    radius = headRadius * 1.2f
                ),
                radius = headRadius,
                center = headCenter
            )

            val bodyTop = size.height * 0.33f
            val bodyBottom = size.height * 0.82f
            val bodyWidth = size.width * 0.34f
            val bodyPath = Path().apply {
                moveTo(dollCenterX - bodyWidth * 0.34f, bodyTop)
                lineTo(dollCenterX + bodyWidth * 0.34f, bodyTop)
                lineTo(dollCenterX + bodyWidth * 0.52f, bodyBottom)
                lineTo(dollCenterX - bodyWidth * 0.52f, bodyBottom)
                close()
            }
            drawPath(
                path = bodyPath,
                brush = Brush.verticalGradient(
                    listOf(Color(0xFFD2B07C), Color(0xFF8A633B), Color(0xFF4E351E))
                )
            )

            repeat(18) { i ->
                val t = i / 17f
                val x1 = dollCenterX - bodyWidth * 0.52f + bodyWidth * t
                val x2 = dollCenterX - bodyWidth * 0.68f + bodyWidth * t
                drawLine(
                    color = Color(0x55F2D5A0),
                    start = Offset(x1, bodyTop + 6f),
                    end = Offset(x2, bodyBottom - 8f),
                    strokeWidth = 2f
                )
            }
            repeat(16) { i ->
                val y = bodyTop + ((bodyBottom - bodyTop) / 15f) * i
                drawLine(
                    color = Color(0x33FFF0BF),
                    start = Offset(dollCenterX - bodyWidth * 0.46f, y),
                    end = Offset(dollCenterX + bodyWidth * 0.46f, y + Random(i + 9).nextInt(-6, 6)),
                    strokeWidth = 1.4f
                )
            }

            fun drawLimb(start: Offset, end: Offset) {
                drawLine(Color(0xFF9B7044), start, end, 18f, cap = StrokeCap.Round)
                repeat(6) { i ->
                    val t = i / 5f
                    val x = start.x + (end.x - start.x) * t
                    val y = start.y + (end.y - start.y) * t
                    drawLine(Color(0x44FFE8B0), Offset(x - 12f, y - 4f), Offset(x + 12f, y + 4f), 1.2f)
                }
            }

            drawLimb(Offset(dollCenterX - bodyWidth * 0.35f, bodyTop + 36f), Offset(dollCenterX - bodyWidth * 0.95f, bodyTop + 78f))
            drawLimb(Offset(dollCenterX + bodyWidth * 0.35f, bodyTop + 36f), Offset(dollCenterX + bodyWidth * 0.95f, bodyTop + 78f))
            drawLimb(Offset(dollCenterX - bodyWidth * 0.18f, bodyBottom - 8f), Offset(dollCenterX - bodyWidth * 0.42f, bodyBottom + 80f))
            drawLimb(Offset(dollCenterX + bodyWidth * 0.18f, bodyBottom - 8f), Offset(dollCenterX + bodyWidth * 0.42f, bodyBottom + 80f))

            drawLine(Color(0xFF2A170B), Offset(dollCenterX, size.height * 0.06f), Offset(dollCenterX, bodyBottom + 76f), 9f, cap = StrokeCap.Round)
            drawLine(Color(0xFF2A170B), Offset(dollCenterX - bodyWidth * 1.05f, bodyTop + 56f), Offset(dollCenterX + bodyWidth * 1.05f, bodyTop + 56f), 9f, cap = StrokeCap.Round)

            drawCircle(Color(0xCC110808), radius = 14f, center = Offset(headCenter.x - headRadius * 0.34f, headCenter.y - 6f))
            drawCircle(Color(0xCC110808), radius = 14f, center = Offset(headCenter.x + headRadius * 0.34f, headCenter.y - 6f))
            drawArc(
                color = Color(0xFF250000),
                startAngle = 10f,
                sweepAngle = 160f,
                useCenter = false,
                topLeft = Offset(headCenter.x - 36f, headCenter.y + 24f),
                size = Size(72f, 34f),
                style = Stroke(width = 5f)
            )

            nails.forEach { nail ->
                val x = nail.xRatio * size.width
                val y = nail.yRatio * size.height
                val bloodR = 12f + nail.bloodSeed * 14f
                drawCircle(Color(0x88A10000), bloodR, Offset(x, y))
                drawCircle(Color(0x55FF3333), bloodR * 0.45f, Offset(x + 4f, y - 2f))
                drawLine(
                    color = Color(0xFFB7B7B7),
                    start = Offset(x, y - 36f),
                    end = Offset(x, y + 10f),
                    strokeWidth = 8f,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = Color(0xFF545454),
                    start = Offset(x - 10f, y - 36f),
                    end = Offset(x + 10f, y - 36f),
                    strokeWidth = 10f,
                    cap = StrokeCap.Round
                )
            }

            repeat(3) { i ->
                val candleX = size.width * (0.17f + i * 0.33f)
                val candleY = size.height * 0.9f
                drawRect(Color(0xFFEEE0C3), topLeft = Offset(candleX - 14f, candleY - 42f), size = Size(28f, 42f))
                drawCircle(Color(0x99FFAA22), 18f, Offset(candleX, candleY - 48f))
                drawCircle(Color(0x55FFD966), 34f, Offset(candleX, candleY - 48f))
            }
        }

        faceBitmap?.let { bitmap ->
            Image(
                painter = BitmapPainter(bitmap.asImageBitmap()),
                contentDescription = "顔写真",
                modifier = Modifier
                    .size(110.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 72.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }

        selectedFace?.let {
            Text(
                text = "顔写真セット済み",
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .background(Color(0xAA220909), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                color = Color(0xFFF1D1D1),
                style = MaterialTheme.typography.labelLarge
            )
        }

        Text(
            text = "画面をタップすると、その位置に釘が刺さる",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp)
                .background(Color(0x88160B0B), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            color = Color(0xFFE6D8C6)
        )
    }
}

private fun playGroan(context: Context) {
    val player = MediaPlayer.create(context, R.raw.groan)
    player?.apply {
        setOnCompletionListener {
            it.release()
        }
        start()
    }
}

private fun vibrate(context: Context) {
    val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        manager.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
    } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(60)
    }
}

private fun loadBitmap(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.isMutableRequired = false
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (_: Exception) {
        null
    }
}
