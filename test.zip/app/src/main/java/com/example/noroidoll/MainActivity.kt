package com.example.noroidoll

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NoroiApp()
                }
            }
        }
    }
}

@Composable
fun NoroiApp() {
    val context = LocalContext.current
    val nails = remember { mutableStateListOf<Offset>() }
    var count by remember { mutableStateOf(0) }

    fun playGroan() {
        val mp = MediaPlayer.create(context, R.raw.groan)
        mp.setOnCompletionListener { player ->
            player.release()
        }
        mp.start()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF111111))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "のろいの藁人形",
            color = Color(0xFFFFE9A8),
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "藁人形をタップして釘を刺す",
            color = Color(0xFFD0D0D0),
            fontSize = 16.sp
        )
        Text(
            text = "刺した本数: $count 本",
            color = Color.White,
            fontSize = 18.sp
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF1E1A16))
                .clickable {
                    val x = Random.nextFloat() * 0.6f + 0.2f
                    val y = Random.nextFloat() * 0.7f + 0.15f
                    nails.add(Offset(x, y))
                    count++
                    playGroan()
                },
            contentAlignment = Alignment.Center
        ) {
            WaraningyoCanvas(nails = nails)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                nails.clear()
                count = 0
            }) {
                Text("釘を抜く")
            }
        }
    }
}

@Composable
fun WaraningyoCanvas(nails: List<Offset>) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(520.dp)
    ) {
        val canvasW = size.width
        val canvasH = size.height
        val centerX = canvasW / 2f

        drawLine(
            color = Color(0xFF4E342E),
            start = Offset(centerX, 0f),
            end = Offset(centerX, canvasH),
            strokeWidth = 18f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF6D4C41),
            start = Offset(centerX - 130f, canvasH * 0.22f),
            end = Offset(centerX + 130f, canvasH * 0.22f),
            strokeWidth = 14f,
            cap = StrokeCap.Round
        )

        drawCircle(
            color = Color(0xFFD2B48C),
            radius = 70f,
            center = Offset(centerX, canvasH * 0.18f)
        )
        drawOval(
            color = Color(0xFFBCA07A),
            topLeft = Offset(centerX - 80f, canvasH * 0.28f),
            size = Size(160f, 180f)
        )

        drawLine(
            color = Color(0xFFD2B48C),
            start = Offset(centerX - 60f, canvasH * 0.34f),
            end = Offset(centerX - 130f, canvasH * 0.48f),
            strokeWidth = 20f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFFD2B48C),
            start = Offset(centerX + 60f, canvasH * 0.34f),
            end = Offset(centerX + 130f, canvasH * 0.48f),
            strokeWidth = 20f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFFD2B48C),
            start = Offset(centerX - 35f, canvasH * 0.62f),
            end = Offset(centerX - 90f, canvasH * 0.84f),
            strokeWidth = 22f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFFD2B48C),
            start = Offset(centerX + 35f, canvasH * 0.62f),
            end = Offset(centerX + 90f, canvasH * 0.84f),
            strokeWidth = 22f,
            cap = StrokeCap.Round
        )

        drawCircle(Color.Black, radius = 7f, center = Offset(centerX - 22f, canvasH * 0.17f))
        drawCircle(Color.Black, radius = 7f, center = Offset(centerX + 22f, canvasH * 0.17f))
        drawArc(
            color = Color(0xFF5D4037),
            startAngle = 15f,
            sweepAngle = 150f,
            useCenter = false,
            topLeft = Offset(centerX - 26f, canvasH * 0.20f),
            size = Size(52f, 26f),
            style = Stroke(width = 4f)
        )

        nails.forEach { normalized ->
            val nailX = normalized.x * canvasW
            val nailY = normalized.y * canvasH
            drawLine(
                color = Color(0xFFC0C0C0),
                start = Offset(nailX - 18f, nailY - 28f),
                end = Offset(nailX, nailY),
                strokeWidth = 8f,
                cap = StrokeCap.Round
            )
            drawCircle(
                color = Color(0xFF8A8A8A),
                radius = 9f,
                center = Offset(nailX - 18f, nailY - 28f)
            )
            drawCircle(
                color = Color(0xFF8B0000),
                radius = 6f,
                center = Offset(nailX, nailY)
            )
        }
    }
}
