package com.example.noroidoll

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FaceRetouchingOff
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.noroidoll.ui.theme.NoroiStrawDollTheme
import kotlin.random.Random

data class NailMark(
    val xRatio: Float,
    val yRatio: Float,
    val angle: Float,
    val deep: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NoroiStrawDollTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    NoroiApp()
                }
            }
        }
    }
}

@Composable
fun NoroiApp() {
    val context = LocalContext.current
    val mediaPlayer = remember { MediaPlayer.create(context, R.raw.groan) }
    DisposableEffect(Unit) { onDispose { mediaPlayer.release() } }

    val nails = remember { mutableStateListOf<NailMark>() }
    var selectedFaceUri by remember { mutableStateOf<Uri?>(null) }
    var curseMessage by remember { mutableStateOf("藁人形をタップして釘を打ち込む…") }
    var nailCount by remember { mutableIntStateOf(0) }
    val latestPlayer by rememberUpdatedState(mediaPlayer)

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        selectedFaceUri = uri
        curseMessage = if (uri != null) "顔写真を藁人形に貼りつけた…" else "写真の選択は見送られた…"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF050505),
                        Color(0xFF140707),
                        Color(0xFF1F0A0A),
                        Color(0xFF050505)
                    )
                )
            )
            .padding(12.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.shrine_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.42f
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            TopPanel(nailCount = nailCount, curseMessage = curseMessage)

            StrawDollBoard(
                nails = nails,
                selectedFaceUri = selectedFaceUri,
                onTap = { xRatio, yRatio ->
                    nails.add(
                        NailMark(
                            xRatio = xRatio,
                            yRatio = yRatio,
                            angle = Random.nextInt(-18, 18).toFloat(),
                            deep = Random.nextBoolean()
                        )
                    )
                    nailCount = nails.size
                    curseMessage = when {
                        nailCount >= 100 -> "呪いが満ちた… ${nailCount}本"
                        nailCount >= 50 -> "うめき声が近い… ${nailCount}本"
                        else -> "釘を打ち込んだ… ${nailCount}本"
                    }
                    playGroan(latestPlayer)
                    vibrate(context)
                }
            )

            BottomPanel(
                onPickFace = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onReset = {
                    nails.clear()
                    nailCount = 0
                    curseMessage = "釘をすべて引き抜いた…"
                }
            )
        }
    }
}

private fun playGroan(player: MediaPlayer) {
    try {
        if (player.isPlaying) player.seekTo(0)
        player.start()
    } catch (_: Exception) {
    }
}

private fun vibrate(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(VibratorManager::class.java)
            manager?.defaultVibrator?.vibrate(
                VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(70)
            }
        }
    } catch (_: Exception) {
    }
}

@Composable
private fun TopPanel(nailCount: Int, curseMessage: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xA6140909)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "のろいの藁人形",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFD6D6)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "釘の本数: $nailCount",
                color = Color(0xFFFFB5B5),
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = curseMessage,
                color = Color(0xFFE8D8D8),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun BottomPanel(onPickFace: () -> Unit, onReset: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0x99100707)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onPickFace,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A1010)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("顔写真を選ぶ")
            }

            Button(
                onClick = onReset,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F2F2F)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("釘を抜く")
            }
        }
    }
}

@Composable
private fun StrawDollBoard(
    nails: SnapshotStateList<NailMark>,
    selectedFaceUri: Uri?,
    onTap: (Float, Float) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .padding(vertical = 12.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xAA090909)),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.waraningyo),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.95f
            )

            selectedFaceUri?.let { uri ->
                AsyncImage(
                    model = uri,
                    contentDescription = "顔写真",
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(100.dp)
                        .background(Color(0xDD2A1818), CircleShape),
                    contentScale = ContentScale.Crop
                )
            } ?: Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(92.dp)
                    .background(Color(0xAA1A1212), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.FaceRetouchingOff,
                    contentDescription = null,
                    tint = Color(0xFFB89797),
                    modifier = Modifier.size(42.dp)
                )
            }

            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val xRatio = (offset.x / size.width).coerceIn(0f, 1f)
                            val yRatio = (offset.y / size.height).coerceIn(0f, 1f)
                            onTap(xRatio, yRatio)
                        }
                    }
            ) {
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0xAA000000)),
                        center = center,
                        radius = size.minDimension * 0.7f
                    )
                )
                drawCandleGlow(size)
                drawAllNails(size, nails)
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCandleGlow(size: Size) {
    val left = Offset(size.width * 0.16f, size.height * 0.77f)
    val right = Offset(size.width * 0.84f, size.height * 0.77f)
    val flameSize = size.minDimension * 0.06f

    listOf(left, right).forEach { base ->
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0x88FFCC66), Color.Transparent)),
            radius = flameSize * 1.8f,
            center = Offset(base.x, base.y - flameSize)
        )
        drawRoundRect(
            color = Color(0xFFD5C7B2),
            topLeft = Offset(base.x - flameSize * 0.3f, base.y),
            size = Size(flameSize * 0.6f, flameSize * 1.7f),
            cornerRadius = CornerRadius(flameSize * 0.2f, flameSize * 0.2f)
        )
        drawOval(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFE4A1), Color(0xFFFF7A00), Color.Transparent)),
            topLeft = Offset(base.x - flameSize * 0.28f, base.y - flameSize * 1.15f),
            size = Size(flameSize * 0.56f, flameSize * 1.12f)
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawAllNails(
    canvasSize: Size,
    nails: List<NailMark>
) {
    nails.forEach { mark ->
        val point = Offset(canvasSize.width * mark.xRatio, canvasSize.height * mark.yRatio)
        val bloodRadius = if (mark.deep) 22f else 16f
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0xCC6A0202), Color(0x88240000), Color.Transparent)),
            radius = bloodRadius,
            center = point,
            blendMode = BlendMode.Multiply
        )
        val nailLength = if (mark.deep) 84f else 70f
        val radians = Math.toRadians(mark.angle.toDouble())
        val dx = kotlin.math.sin(radians).toFloat() * nailLength * 0.3f
        val dy = kotlin.math.cos(radians).toFloat() * nailLength
        drawLine(
            color = Color(0xFFB6BCC5),
            start = Offset(point.x - dx, point.y - dy * 0.75f),
            end = Offset(point.x + dx * 0.25f, point.y + dy * 0.15f),
            strokeWidth = 10f,
            cap = StrokeCap.Round,
            pathEffect = PathEffect.cornerPathEffect(6f)
        )
        drawLine(
            color = Color(0xFF6B7078),
            start = Offset(point.x - dx * 1.1f, point.y - dy * 0.88f),
            end = Offset(point.x - dx * 0.55f, point.y - dy * 0.88f),
            strokeWidth = 16f,
            cap = StrokeCap.Round
        )
        drawCircle(color = Color(0xAA180101), radius = 8f, center = point)
    }
}
