# WeatherTalkerAgent (No API Key)

- Weather: Open-Meteo (no API key)
- Speak: Android TextToSpeech (offline)
- Simple rule-based "agent" (no LLM)

## How to use
1. Input latitude / longitude
2. Tap "Get Weather"
3. Tap "Speak"
