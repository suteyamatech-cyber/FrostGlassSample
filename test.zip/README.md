# NeoNavWeatherYTM

- Weather: Open-Meteo (no API key)
- Map: OpenStreetMap (osmdroid) with CartoDB dark tiles (no API key)
- Location: FusedLocationProvider
- Music: YouTube Music title/artist/album art via Notification Listener + MediaSession (no API key)

## Required (on device)
- Enable Notification Access for this app to show YouTube Music info.
