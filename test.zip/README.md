# NeoWeatherMusic (GPS + Weather + Music)

- GPS auto (FusedLocationProvider lastLocation)
- Weather via Open-Meteo (no API key)
- Music playback via Media3 ExoPlayer (sample streaming MP3)
- Futuristic themed Compose UI

How to use:
1) First launch: allow location permission.
2) Tap "Get GPS" then "Get Weather".
3) Tap Play to start music.
