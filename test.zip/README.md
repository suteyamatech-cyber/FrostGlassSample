# NeoWeatherMusic v1.2 (test.zip)

✅ Changes:
- Map is now OpenStreetMap (osmdroid) -> NO API KEY required
- Status bar overlap fixed (systemBars padding)
- Futuristic weather icon (pure Canvas neon style) + TTS

Features:
- GPS auto (FusedLocationProvider lastLocation)
- Weather via Open-Meteo (no API key)
- OSM map + marker (osmdroid)
- Music playback (sample stream) + Spotify app open (simple integration)
- TTS: speaks weather summary

Notes:
- First launch: allow location permission.
- If map tiles don't load on some networks, try again later (tile server).


## v1.3 updates
- Dark map tiles (CartoDB Dark Matter)
- Car-nav zoom (18.5) + pseudo-3D rotation (mapOrientation)
- Futuristic neon pin marker
- Spotify song title display + controls via Notification Access (no API key). Enable in Settings.

- Spotify title/artist also read from Spotify notification extras for better reliability (still needs Notification Access).
