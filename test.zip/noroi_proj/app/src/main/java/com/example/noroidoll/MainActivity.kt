package com.example.noroidoll

import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = MaterialTheme.colorScheme.copy(
                    background = Color(0xFF070707),
                    surface = Color(0xFF161010),
                    primary = Color(0xFF9B1C1C),
                    secondary = Color(0xFFB38B59),
                    onBackground = Color(0xFFF5E9D2),
                    onSurface = Color(0xFFF5E9D2)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NoroiApp()
                }
            }
        }
    }
}

data class NailMark(
    val xRatio: Float,
    val yRatio: Float,
    val jitter: Float
)

@Composable
private fun NoroiApp() {
    val context = LocalContext.current
    val nails = remember { mutableStateListOf<NailMark>() }
    var selectedFaceUri by remember { mutableStateOf<Uri?>(null) }
    var boardSize by remember { mutableStateOf(IntSize.Zero) }
    var flashAlpha by remember { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        selectedFaceUri = uri
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 16.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "のろいの藁人形",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFF2D6A2)
        )
        Text(
            text = "顔写真を貼って、タップした位置に釘を刺します",
            color = Color(0xFFBCA98A),
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    imagePicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Face, contentDescription = null)
                Spacer(modifier = Modifier.size(8.dp))
                Text("顔写真を選ぶ")
            }

            Button(
                onClick = { nails.clear() },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.size(8.dp))
                Text("釘を抜く")
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF120B0B)),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .onSizeChanged { boardSize = it }
                    .pointerInput(boardSize) {
                        detectTapGestures { tapOffset ->
                            if (boardSize.width <= 0 || boardSize.height <= 0) return@detectTapGestures
                            val mark = NailMark(
                                xRatio = (tapOffset.x / boardSize.width.toFloat()).coerceIn(0f, 1f),
                                yRatio = (tapOffset.y / boardSize.height.toFloat()).coerceIn(0f, 1f),
                                jitter = Random.nextFloat()
                            )
                            nails.add(mark)
                            playGroan(context)
                            vibrate(context)
                            scope.launch {
                                flashAlpha = 0.35f
                                delay(110)
                                flashAlpha = 0f
                            }
                        }
                    }
            ) {
                CreepyShrineBackground(modifier = Modifier.fillMaxSize())
                StrawDollFaceBoard(
                    modifier = Modifier.fillMaxSize(),
                    faceUri = selectedFaceUri,
                    nails = nails,
                    boardSize = boardSize
                )
                if (flashAlpha > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0x66AA0000).copy(alpha = flashAlpha))
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "刺さった釘: ${nails.size} 本",
            color = Color(0xFFE6C78F),
            style = MaterialTheme.typography.titleMedium
        )
    }
}

@Composable
private fun CreepyShrineBackground(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFF050505), Color(0xFF1C0F0F), Color(0xFF050505))
            )
        )

        val candleY = size.height * 0.83f
        val leftX = size.width * 0.15f
        val rightX = size.width * 0.85f
        drawCandle(leftX, candleY)
        drawCandle(rightX, candleY)

        for (i in 0..12) {
            val x = size.width * i / 12f
            drawLine(
                color = Color(0x22FFFFFF),
                start = Offset(x, size.height * 0.08f),
                end = Offset(x + 30f, size.height * 0.92f),
                strokeWidth = 2f
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCandle(x: Float, y: Float) {
    drawRoundRect(
        color = Color(0xFFD7C4A1),
        topLeft = Offset(x - 18f, y - 90f),
        size = Size(36f, 90f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
    )
    drawCircle(
        color = Color(0x55FFAA33),
        radius = 35f,
        center = Offset(x, y - 105f)
    )
    val flame = Path().apply {
        moveTo(x, y - 150f)
        quadraticBezierTo(x - 24f, y - 105f, x, y - 82f)
        quadraticBezierTo(x + 20f, y - 110f, x, y - 150f)
    }
    drawPath(flame, color = Color(0xFFFFB347))
}

@Composable
private fun StrawDollFaceBoard(
    modifier: Modifier,
    faceUri: Uri?,
    nails: List<NailMark>,
    boardSize: IntSize
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val bodyTop = h * 0.14f
            val bodyBottom = h * 0.88f
            val centerX = w * 0.5f
            val bodyWidth = min(w, h) * 0.33f

            drawRoundRect(
                color = Color(0xFFB48A53),
                topLeft = Offset(centerX - bodyWidth / 2f, bodyTop),
                size = Size(bodyWidth, bodyBottom - bodyTop),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(60f, 60f)
            )

            for (i in 0..18) {
                val ratio = i / 18f
                val y = bodyTop + (bodyBottom - bodyTop) * ratio
                drawLine(
                    color = Color(0x88704B22),
                    start = Offset(centerX - bodyWidth / 2f + 10f, y),
                    end = Offset(centerX + bodyWidth / 2f - 10f, y + 8f),
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )
            }

            drawLine(
                color = Color(0xFFB48A53),
                start = Offset(centerX - bodyWidth / 1.1f, h * 0.36f),
                end = Offset(centerX + bodyWidth / 1.1f, h * 0.36f),
                strokeWidth = bodyWidth * 0.17f,
                cap = StrokeCap.Round
            )

            drawLine(
                color = Color(0xFFB48A53),
                start = Offset(centerX - bodyWidth * 0.18f, bodyBottom),
                end = Offset(centerX - bodyWidth * 0.33f, h * 0.98f),
                strokeWidth = bodyWidth * 0.13f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color(0xFFB48A53),
                start = Offset(centerX + bodyWidth * 0.18f, bodyBottom),
                end = Offset(centerX + bodyWidth * 0.33f, h * 0.98f),
                strokeWidth = bodyWidth * 0.13f,
                cap = StrokeCap.Round
            )

            drawCircle(
                color = Color(0x22000000),
                radius = bodyWidth * 0.24f,
                center = Offset(centerX, h * 0.24f)
            )
        }

        if (faceUri != null) {
            AsyncImage(
                model = faceUri,
                contentDescription = "顔写真",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(112.dp)
                    .offset(y = (-78).dp)
                    .clip(CircleShape)
                    .border(3.dp, Color(0xFFEBD9B7), CircleShape)
                    .clickable(enabled = false) {}
            )
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val widthPx = boardSize.width.toFloat().takeIf { it > 0f } ?: size.width
            val heightPx = boardSize.height.toFloat().takeIf { it > 0f } ?: size.height
            nails.forEach { nail ->
                val x = nail.xRatio * widthPx
                val y = nail.yRatio * heightPx
                drawCircle(color = Color(0xAA6E0000), radius = 22f, center = Offset(x, y))
                drawLine(
                    color = Color(0xFFD6D6D6),
                    start = Offset(x, y - 52f),
                    end = Offset(x, y + 12f),
                    strokeWidth = 10f,
                    cap = StrokeCap.Round
                )
                drawCircle(color = Color(0xFF5A5A5A), radius = 16f, center = Offset(x, y - 56f))
                drawLine(
                    color = Color(0x44FFFFFF),
                    start = Offset(x - 16f, y - 56f),
                    end = Offset(x + 16f, y - 56f),
                    strokeWidth = 3f
                )
                drawCircle(
                    color = Color(0x44FF0000),
                    radius = 30f + nail.jitter * 18f,
                    center = Offset(x, y)
                )
            }

            drawLine(
                color = Color(0x99FFFFFF),
                start = Offset(size.width * 0.46f, size.height * 0.34f),
                end = Offset(size.width * 0.54f, size.height * 0.39f),
                strokeWidth = 5f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color(0x99FFFFFF),
                start = Offset(size.width * 0.54f, size.height * 0.34f),
                end = Offset(size.width * 0.46f, size.height * 0.39f),
                strokeWidth = 5f,
                cap = StrokeCap.Round
            )
        }
    }
}

private fun playGroan(context: android.content.Context) {
    val mediaPlayer = MediaPlayer.create(context, R.raw.groan)
    mediaPlayer?.apply {
        setOnCompletionListener { mp ->
            mp.release()
        }
        start()
    }
}

private fun vibrate(context: android.content.Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(VibratorManager::class.java)
        manager?.defaultVibrator?.vibrate(
            VibrationEffect.createOneShot(55, VibrationEffect.DEFAULT_AMPLITUDE)
        )
    } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(55, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(55)
        }
    }
}
