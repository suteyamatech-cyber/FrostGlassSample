package com.example.noroidoll

import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.noroidoll.ui.theme.NoroiDollTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NoroiDollTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    NoroiDollApp()
                }
            }
        }
    }
}

data class NailMark(val xRatio: Float, val yRatio: Float)

@Composable
fun NoroiDollApp() {
    val context = LocalContext.current
    val nails = remember { mutableStateListOf<NailMark>() }
    var selectedFaceUri by remember { mutableStateOf<Uri?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        selectedFaceUri = uri
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(horizontal = 12.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "のろいの藁人形",
            color = Color(0xFFFFD7A3),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
        ) {
            val boxWidth = constraints.maxWidth.toFloat().coerceAtLeast(1f)
            val boxHeight = constraints.maxHeight.toFloat().coerceAtLeast(1f)

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF080506))
                    .pointerInput(Unit) {
                        detectTapGestures { position ->
                            val xRatio = (position.x / boxWidth).coerceIn(0f, 1f)
                            val yRatio = (position.y / boxHeight).coerceIn(0f, 1f)
                            nails.add(NailMark(xRatio, yRatio))
                            playGroan(context)
                            vibrate(context)
                        }
                    }
            ) {
                ShrineBackground()
                StrawDollImage()

                selectedFaceUri?.let { uri ->
                    AsyncImage(
                        model = uri,
                        contentDescription = "選択した顔写真",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(bottom = 84.dp)
                            .size(104.dp)
                            .clip(CircleShape)
                    )
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                ) {
                    nails.forEach { nail ->
                        val cx = nail.xRatio * size.width
                        val cy = nail.yRatio * size.height
                        drawNail(center = Offset(cx, cy))
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A1010))
            ) {
                Text("顔写真を選ぶ")
            }
            Button(
                onClick = { nails.clear() },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3D3D3D))
            ) {
                Text("釘を抜く")
            }
        }

        Text(
            text = "打ち込んだ釘: ${nails.size}本",
            color = Color(0xFFFFC7C7),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun ShrineBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF12090B), Color(0xFF251011), Color(0xFF040404))
            )
        )

        val fogCount = 7
        repeat(fogCount) { index ->
            drawCircle(
                color = Color.White.copy(alpha = 0.035f),
                radius = size.minDimension * (0.16f + 0.03f * index),
                center = Offset(size.width * (0.12f + 0.12f * index), size.height * (0.72f - 0.05f * (index % 3)))
            )
        }

        val candleXs = listOf(0.12f, 0.24f, 0.78f, 0.9f)
        candleXs.forEach { ratio ->
            val x = size.width * ratio
            val baseY = size.height * 0.88f
            drawRect(
                color = Color(0xFFF5E6C8),
                topLeft = Offset(x - 10f, baseY - 80f),
                size = androidx.compose.ui.geometry.Size(20f, 80f)
            )
            drawCircle(
                color = Color(0xFFFFB347).copy(alpha = 0.55f),
                radius = 38f,
                center = Offset(x, baseY - 92f)
            )
            drawCircle(
                color = Color(0xFFFFE3A1),
                radius = 14f,
                center = Offset(x, baseY - 98f)
            )
        }
    }
}

@Composable
private fun StrawDollImage() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val bodyCenterX = size.width / 2f
        val bodyTop = size.height * 0.18f
        val bodyBottom = size.height * 0.86f
        val bodyWidth = size.width * 0.33f
        val armY = size.height * 0.42f
        val armWidth = size.width * 0.68f
        val straw = Color(0xFFB8924C)
        val outline = Color(0xFF2B1607)

        drawRoundRect(
            color = straw,
            topLeft = Offset(bodyCenterX - bodyWidth / 2f, bodyTop),
            size = androidx.compose.ui.geometry.Size(bodyWidth, bodyBottom - bodyTop),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(80f, 80f)
        )

        drawRoundRect(
            color = straw,
            topLeft = Offset(bodyCenterX - armWidth / 2f, armY),
            size = androidx.compose.ui.geometry.Size(armWidth, size.height * 0.08f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(50f, 50f)
        )

        drawLine(
            color = outline,
            start = Offset(bodyCenterX - bodyWidth / 2f, bodyTop + 6f),
            end = Offset(bodyCenterX + bodyWidth / 2f, bodyTop + 6f),
            strokeWidth = 4f
        )
        drawLine(
            color = outline,
            start = Offset(bodyCenterX - armWidth / 2f, armY + 8f),
            end = Offset(bodyCenterX + armWidth / 2f, armY + 8f),
            strokeWidth = 4f
        )

        for (i in 0..24) {
            val y = bodyTop + (bodyBottom - bodyTop) * i / 24f
            drawLine(
                color = outline.copy(alpha = 0.28f),
                start = Offset(bodyCenterX - bodyWidth / 2f + 12f, y),
                end = Offset(bodyCenterX + bodyWidth / 2f - 12f, y - 8f),
                strokeWidth = 2f
            )
        }

        val ropeYs = listOf(size.height * 0.33f, size.height * 0.54f, size.height * 0.72f)
        ropeYs.forEach { y ->
            drawLine(
                color = Color(0xFF4E2B18),
                start = Offset(bodyCenterX - bodyWidth * 0.6f, y),
                end = Offset(bodyCenterX + bodyWidth * 0.6f, y),
                strokeWidth = 10f
            )
        }

        drawCircle(
            color = Color(0x99AA1111),
            radius = size.minDimension * 0.065f,
            center = Offset(bodyCenterX, size.height * 0.58f)
        )

        val stringPath = Path().apply {
            moveTo(bodyCenterX, bodyTop - 40f)
            quadraticBezierTo(bodyCenterX - 30f, bodyTop - 100f, bodyCenterX + 5f, bodyTop - 160f)
        }
        drawPath(path = stringPath, color = Color(0xFF7A5A3A), style = Stroke(width = 10f))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawNail(center: Offset) {
    drawLine(
        color = Color(0xFFD0D0D0),
        start = Offset(center.x, center.y - 28f),
        end = Offset(center.x, center.y + 18f),
        strokeWidth = 7f
    )
    drawCircle(color = Color(0xFF5A5A5A), radius = 12f, center = Offset(center.x, center.y - 32f))
    drawCircle(color = Color(0xAA7F0000), radius = 18f, center = Offset(center.x, center.y + 2f))
}

private fun playGroan(context: android.content.Context) {
    runCatching {
        MediaPlayer.create(context, R.raw.groan)?.apply {
            setOnCompletionListener { player -> player.release() }
            start()
        }
    }
}

private fun vibrate(context: android.content.Context) {
    runCatching {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(VibratorManager::class.java)
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Vibrator::class.java)
        }
        vibrator?.vibrate(VibrationEffect.createOneShot(70L, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
