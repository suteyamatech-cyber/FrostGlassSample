package com.example.noroidoll.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NoroiColors = darkColorScheme(
    primary = Color(0xFFB23A3A),
    secondary = Color(0xFFE2C18E),
    background = Color(0xFF050505),
    surface = Color(0xFF101010),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color(0xFFF5EDE2),
    onSurface = Color(0xFFF5EDE2)
)

@Composable
fun NoroiDollTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NoroiColors,
        content = content
    )
}
