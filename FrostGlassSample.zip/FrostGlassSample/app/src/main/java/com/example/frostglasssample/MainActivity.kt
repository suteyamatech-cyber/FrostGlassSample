package com.example.frostglasssample

import android.os.Build
import android.os.Bundle
import android.graphics.RenderEffect
import android.graphics.Shader
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App() {
    MaterialTheme {
        var blur by remember { mutableStateOf(24f) }
        var alpha by remember { mutableStateOf(0.40f) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                // 背景は適当なカラーブロック（本来は写真/地図/動画など）
                .background(Color(0xFF101820))
        ) {
            BackgroundBlocks()

            // くもりガラス用パネル（API 31+ で本物のブラー）
            FrostedPanel(
                blurRadius = blur,
                overlayAlpha = alpha,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .fillMaxWidth()
            )

            // コントロール
            ControlPanel(
                blur = blur,
                onBlurChange = { blur = it },
                alpha = alpha,
                onAlphaChange = { alpha = it },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(20.dp)
            )
        }
    }
}

@Composable
private fun BackgroundBlocks() {
    // 雑に“動き”が出るような配色ブロックを置く
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF1B4D89)))
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF5B8C5A)))
        }
        Row(Modifier.weight(1f).fillMaxWidth()) {
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF9E2A2B)))
            Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFFE09F3E)))
        }
    }
}

@Composable
private fun FrostedPanel(
    blurRadius: Float,
    overlayAlpha: Float,
    modifier: Modifier = Modifier
) {
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    val renderEffect = remember(blurRadius) {
        if (canBlur) {
            RenderEffect
                .createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP)
                .asComposeRenderEffect()
        } else null
    }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .then(
                if (renderEffect != null) Modifier.graphicsLayer { this.renderEffect = renderEffect }
                else Modifier
            )
            // ガラス感：白の半透明オーバーレイ（ブラーなしでも“それっぽく”見える）
            .background(Color.White.copy(alpha = overlayAlpha))
            .padding(20.dp)
    ) {
        Text("Frosted Glass Sample", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            if (canBlur) "API 31+ なので RenderEffect のブラーが有効です。"
            else "API 30 以下なので疑似ガラス（半透明オーバーレイ）です。",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "背景に写真を置いたり、背後にリストや地図を置くと “くもりガラス” が分かりやすいです。",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun ControlPanel(
    blur: Float,
    onBlurChange: (Float) -> Unit,
    alpha: Float,
    onAlphaChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Tweak", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))

            Text("Blur radius: ${blur.toInt()}")
            Slider(
                value = blur,
                onValueChange = onBlurChange,
                valueRange = 0f..40f
            )

            Spacer(Modifier.height(6.dp))
            Text("Overlay alpha: ${"%.2f".format(alpha)}")
            Slider(
                value = alpha,
                onValueChange = onAlphaChange,
                valueRange = 0.10f..0.70f
            )
        }
    }
}
