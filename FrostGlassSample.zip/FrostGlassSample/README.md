# FrostGlassSample

Android (Compose) の “くもりガラス” サンプルです。

- API 31+ : RenderEffect で本物のブラー
- API 30以下: 半透明オーバーレイで疑似ガラス

## ビルド方法（PCで）

1. Android Studio をインストール
2. このフォルダを Open
3. Gradle Sync
4. Run もしくは Build > Build Bundle(s) / APK(s) > Build APK(s)

CLIの場合（Android SDKが入っている環境）
- ./gradlew :app:assembleDebug

出力:
- app/build/outputs/apk/debug/app-debug.apk
